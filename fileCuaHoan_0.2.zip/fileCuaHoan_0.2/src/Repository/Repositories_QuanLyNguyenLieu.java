/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import Config.DBConnect;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import Entity.Model_SanPham;
import Entity.Model_DanhMuc;
import Entity.Model_NguyenLieu;

/**
 *
 * @author Dell
 */
public class Repositories_QuanLyNguyenLieu {
//    private DefaultTableModel mol = new DefaultTableModel();
//    private 
//    

    private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql = null;

    public ArrayList<Model_NguyenLieu> getListNL() {
        // Tạo câu SQL
        String sql = "select MaNL,TenNL,SoLuong,DonVi,MoTa,TrangThai,IDNL from NguyenLieu";

        ArrayList<Model_NguyenLieu> list = new ArrayList<>();

        try (
                Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // Thực thi truy vấn
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String ma = rs.getString(1);
                String ten = rs.getString(2);
                float giaBan = rs.getFloat(3);
                String DonVi = rs.getString(4);
                String MoTa = rs.getString(5);
                int trangThai = rs.getInt(6);
                int IDNL =rs.getInt(7);
                Model_NguyenLieu nl = new Model_NguyenLieu(IDNL, ma, ten, giaBan, DonVi, MoTa, trangThai);

                list.add(nl);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public int themNL(Model_NguyenLieu m) {
        sql = " insert into NguyenLieu(TenNL,SoLuong,DonVi,MoTa,TrangThai)values(?,?,?,?,?)";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, m.getTenNL());
            ps.setObject(2, m.getSoLuong());
            ps.setObject(3, m.getDonVi());
            ps.setObject(4, m.getMoTa());
            ps.setObject(5, m.getTrangThai());
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int capNhatNL(Model_NguyenLieu m) {
        sql = "update NguyenLieu set TenNL=?,SoLuong=?,DonVi=?,MoTa=?,TrangThai=? where MaNL=?";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, m.getTenNL());
            ps.setObject(2, m.getSoLuong());
            ps.setObject(3, m.getDonVi());
            ps.setObject(4, m.getMoTa());
            ps.setObject(5, m.getTrangThai());
            ps.setObject(6, m.getMaNl());
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
//    public ArrayList<Model_SanPham> TimKiem() {
//        // Tao cau sql
//        String sql = "select sp.IDSP,sp.MaSP,sp.TenSP,sp.GiaSP,dm.TenDM,sp.HinhAnh,sp.TrangThai from SanPham sp inner join DanhMuc dm on sp.IDDM=dm.IDDM";
//        ArrayList<Model_SanPham> list = new ArrayList<>();
//        // ket noi co so du lieu va thuc thi truy van
//        try (
//            Connection conn = DBConnect.getConnection(); 
//            PreparedStatement ps = conn.prepareStatement(sql)) {
//            // thuc thi truy van
//            ResultSet rs = ps.executeQuery();
//            // doc tung ban ghi vaf convert sang doi tuong hoa don
//            while (rs.next()) {
//                int id = rs.getInt(1);
//                String ma = rs.getString(2);
//                String ten = rs.getString(3);
//                double giaBan = rs.getDouble(4);
//                String Tendm = rs.getString(5);
//                String HinhAnh = rs.getString(6);
//                boolean trangThai = rs.getBoolean(7);
//                
//                Model_SanPham sp = new Model_SanPham(id,ma,ten,giaBan,Tendm,HinhAnh,trangThai);
//                
//                list.add(sp);
//            }
//            return list;
//        } catch (Exception e) {
//            e.printStackTrace();
//           return null;
//        }       
//    }

}
