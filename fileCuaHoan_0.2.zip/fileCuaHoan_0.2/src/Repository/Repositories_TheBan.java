/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import Config.DBConnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Entity.Model_TheBan;
import java.util.ArrayList;
import Entity.Model_HoaDon;

/**
 *
 * @author Dell
 */
public class Repositories_TheBan {
    private Connection con =null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql=null;
    
    
    
    public ArrayList<Model_TheBan> getTheBan(){
        sql="select * from TheBan";
        ArrayList<Model_TheBan> listtb = new ArrayList<>();
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
                
             
            Model_TheBan tb  = new Model_TheBan(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getBoolean(4),rs.getString(5),rs.getString(6));
            listtb.add(tb);
            }
            return listtb;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }      
    }
    public ArrayList<Model_TheBan> getTheBanTrong(){
        sql="select * from TheBan where TrangThai=0";
        ArrayList<Model_TheBan> listtb = new ArrayList<>();
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
                
             
            Model_TheBan tb  = new Model_TheBan(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getBoolean(4),rs.getString(5),rs.getString(6));
            listtb.add(tb);
            }
            return listtb;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }      
    }
    public ArrayList<Model_TheBan> getTheBanDangSuDung(){
        sql="select * from TheBan where TrangThai=1";
        ArrayList<Model_TheBan> listtb = new ArrayList<>();
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
                
             
            Model_TheBan tb  = new Model_TheBan(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getBoolean(4),rs.getString(5),rs.getString(6));
            listtb.add(tb);
            }
            return listtb;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }      
    }
    public int MoBan(int IDTB){
        sql="update TheBan set TrangThai = 1 where IDTB =?";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, IDTB);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
        
    }
    public int DongBan(String tenBan){
        sql="update TheBan set TrangThai = 0 where TenBan= ?";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, tenBan);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }    
    }
    
    public Model_HoaDon getHoaDonByBan(int IDTB) {
        String sql = "SELECT hd.IDHD, hd.MaHD, hd.NgayTao, nv.HoTen, " +
                     "   COALESCE(SUM(ct.SoLuong * ct.GiaBan), 0) AS 'Tổng tiền', " +
                     "    tb.TenBan, hd.TrangThai, " +
                     "   COALESCE(vc.PhanTramGiam, 0) AS PhanTramGiam, " +
                     "   kh.HoTen, kh.SDT, nv.MaNV, " +
                     "   COALESCE(SUM(ct.SoLuong * ct.GiaBan), 0) * (1 - COALESCE(vc.PhanTramGiam, 0) / 100.0) AS 'Tổng tiền cần thanh toán', vc.TenVC " +
                     "FROM HoaDon hd " +
                     "LEFT JOIN HoaDonChiTiet ct ON ct.IDHD = hd.IDHD " +
                     "INNER JOIN TheBan tb ON tb.IDTB = hd.IDBan " +
                     "INNER JOIN NhanVien nv ON nv.IDNV = hd.IDNV " +
                     "LEFT JOIN Voucher vc ON vc.IDVC = hd.IDVC " +
                     "LEFT JOIN KhachHang kh ON kh.IDKH = hd.IDKH " +
                     "WHERE tb.IDTB=? AND hd.TrangThai = 0 " +
                     "GROUP BY hd.IDHD, hd.MaHD, hd.NgayTao, nv.HoTen, tb.TenBan, hd.TrangThai, vc.PhanTramGiam, kh.HoTen, kh.SDT, nv.MaNV, vc.TenVC " +
                     "ORDER BY CASE WHEN hd.TrangThai = 0 THEN 0 ELSE 1 END, hd.NgayTao DESC;";
        Model_HoaDon hd = null;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1, IDTB);
            rs = ps.executeQuery();
            if (rs.next()) {
                int id = rs.getInt(1);
                String MaHD = rs.getString(2);
                String NgayTao = rs.getString(3);
                String HoTenNV = rs.getString(4);
                double TongTien = rs.getDouble(5);
                String TenBan = rs.getString(6);
                boolean trangThai = rs.getBoolean(7);
                int phanTramGiamGia = rs.getInt(8);
                String HoTenKhachHang = rs.getString(9);
                String SDTKH = rs.getString(10);
                String MaNV = rs.getString(11);
                double TongCong = rs.getDouble(12);
                String TenVC = rs.getString(13);

                hd = new Model_HoaDon(id, MaHD, TongTien, TenBan, HoTenNV, trangThai, NgayTao, MaNV, phanTramGiamGia, HoTenKhachHang, SDTKH, TongCong, TenVC);
                System.out.println("MAHD REPO: " + hd.getIDHD());
            }
            return hd;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            // Đảm bảo đóng các kết nối, statement và result set
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    

    
}
