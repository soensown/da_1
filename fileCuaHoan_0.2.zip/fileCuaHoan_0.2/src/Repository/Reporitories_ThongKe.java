/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import Config.DBConnect;
import Entity.Model_ThongKe;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class Reporitories_ThongKe {

    private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql = null;

    public ArrayList<Model_ThongKe> getListtKH() {
        // Tao cau sql
        sql = "select top 5 kh.MaKH,kh.HoTen,kh.SDT,sum(TongTien) from HoaDon hd inner join KhachHang kh on hd.IDKH=kh.IDKH \n" +
"group by kh.MaKH,kh.HoTen,kh.SDT\n" +
"order by sum(TongTien) desc";

        ArrayList<Model_ThongKe> list = new ArrayList<>();
        // ket noi co so du lieu va thuc thi truy van
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // thuc thi truy van
            ResultSet rs = ps.executeQuery();
            // doc tung ban ghi vaf convert sang doi tuong hoa don
            while (rs.next()) {
                String makh = rs.getString(1);
                String tenkh = rs.getString(2);
                String sdt = rs.getString(3);
                Float tongtien = rs.getFloat(4);
                Model_ThongKe model_ThongKe = new Model_ThongKe(makh, sdt, sdt, tongtien);
                list.add(model_ThongKe);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getmonth1() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 1";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth2() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 2";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth3() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 3";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth4() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 4";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth5() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 5";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth6() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 6";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth7() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 7";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth8() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 8";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth9() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 9";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth10() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 10";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth11() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 11";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int getmonth12() {
        int box = 0;
        String sql = "select sum(TongTien) as tongtien from HoaDon where HinhThucThanhToan = 1 and MONTH(NgayTao) = 12";
        try (Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                box = rs.getInt(1);
            }
            return box;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public double sumDay() {
        sql = "select Sum(TongTien) from HoaDon  where day(GETDATE()) = DAY(GioThanhToan)";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
        return 0;
    }
    public double DangPhucVu() {
        sql = "select Sum(TongTien) from HoaDon  where TrangThai=0";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
        return 0;
    }
    public double sumMonth() {
        sql = "select Sum(TongTien) from HoaDon  where month(GETDATE()) = month(GioThanhToan)";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
        }
        return 0;
    }

    public double sumYear() {
        sql = "select Sum(TongTien) from HoaDon  where year(GETDATE()) = year(GioThanhToan)";
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
        }
        return 0;
    }

    public String demSoLuongHD(String start_date, String end_date) {
        sql = """
            select count(IDHD) As SOLuongHD from HoaDon 
              
            where NgayTao >= ? and NgayTao <= ?
              """;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, start_date);
            ps.setString(2, end_date);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException e) {
        }
        return null;
    }

    public String soLuongCacSPDaBan(String start_date, String end_date) {
        sql = """
            select sum(soLuong) As SoLuongDaban from HoaDonChiTiet where  ngayTao >= ? and ngayTao <= ?
              """;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, start_date);
            ps.setString(2, end_date);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException e) {
        }
        return null;
    }

    public String tongTienDaBan(String start_date, String end_date) {
        sql = """
            select sum(TongTien) from HoaDon where ngayTao >= ? and ngayTao <= ?
              """;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, start_date);
            ps.setString(2, end_date);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getString(1);
            }
        } catch (SQLException e) {
        }
        return null;
    }
}
