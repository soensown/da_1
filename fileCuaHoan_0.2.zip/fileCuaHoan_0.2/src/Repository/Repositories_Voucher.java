/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import Config.DBConnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Entity.Model_Voucher;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Repositories_Voucher {
    private Connection con =null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql=null;
    
    
    public ArrayList<Model_Voucher> getVoucher(){
        sql="select * from Voucher where NgayBatDau<getDate() and NgayKetThuc>GETDATE()";
        ArrayList<Model_Voucher> listDM = new ArrayList<>();
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                
                
                
            Model_Voucher dm = new Model_Voucher(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9));
            listDM.add(dm);
            }
            return listDM;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }      
    }
}
