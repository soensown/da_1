/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import Config.DBConnect;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import Entity.Model_SanPham;
import Entity.Model_DanhMuc;
import Entity.Model_NguyenLieu;
import Entity.Model_nguyenLieuChiTiet;

/**
 *
 * @author Dell
 */
public class Repositories_QuanLyNguyenLieuChiTiet {
//    private DefaultTableModel mol = new DefaultTableModel();
//    private 
//    

    private Connection con = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql = null;

    public ArrayList<Model_NguyenLieu> getListNL() {
        // Tạo câu SQL
        String sql = "select MaNL,TenNL,SoLuong,DonVi,MoTa,TrangThai,IDNL from NguyenLieu";

        ArrayList<Model_NguyenLieu> list = new ArrayList<>();

        try (
                Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // Thực thi truy vấn
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                String ma = rs.getString(1);
                String ten = rs.getString(2);
                float giaBan = rs.getFloat(3);
                String DonVi = rs.getString(4);
                String MoTa = rs.getString(5);
                int trangThai = rs.getInt(6);
                int IDNL=rs.getInt(7);
                Model_NguyenLieu nl = new Model_NguyenLieu(IDNL, ma, ten, giaBan, DonVi, MoTa, trangThai);

                list.add(nl);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public Integer XoaNguyenLieuChiTiet(int IDSP,int IDNL ){
        sql="delete NguyenLieuChiTiet where IDSP = ? and IDNL =?";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, IDSP);
            ps.setObject(2, IDNL);         
            System.out.println("IDSP"+IDSP);
            System.out.println("IDHD"+IDNL);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public Integer themNguyenLieuChiTiet(Model_nguyenLieuChiTiet nl){
        sql="insert into NguyenLieuChiTiet (IDSP,IDNL,SoLuongSuDung,MoTa) values (?,?,?,?)";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, nl.getIDSP());
            ps.setObject(2, nl.getIDNL());
            ps.setObject(3, nl.getSoLuongSuDung());
            ps.setObject(4, nl.getMota());
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public ArrayList<Model_nguyenLieuChiTiet> getListNLCT() {
        // Tạo câu SQL
        String sql = "select IDSP,IDNL,SoLuongSuDung,MoTa from NguyenLieuChiTiet";

        ArrayList<Model_nguyenLieuChiTiet> list = new ArrayList<>();

        try (
                Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // Thực thi truy vấn
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int maSp = rs.getInt(1);
                int maNl = rs.getInt(2);
                float luotDung = rs.getFloat(3);
                String MoTa = rs.getString(4);
                Model_nguyenLieuChiTiet nlCt = new Model_nguyenLieuChiTiet(maSp, maNl, luotDung, MoTa);

                list.add(nlCt);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public ArrayList<Model_SanPham> getListSp() {
        // Tạo câu SQL
        String sql = "SELECT sp.IDSP, sp.MaSP, sp.TenSP, sp.GiaSP, dm.TenDM, sp.HinhAnh, sp.TrangThai, "
                + "COALESCE(MIN(CASE WHEN nl.SoLuong / nlct.SoLuongSuDung < 1 THEN 0 ELSE FLOOR(nl.SoLuong / nlct.SoLuongSuDung) END), 0) AS SoLuongTonKho "
                + "FROM SanPham sp "
                + "INNER JOIN DanhMuc dm ON sp.IDDM = dm.IDDM "
                + "LEFT JOIN NguyenLieuChiTiet nlct ON nlct.IDSP = sp.IDSP "
                + "LEFT JOIN NguyenLieu nl ON nl.IDNL = nlct.IDNL "
                + "GROUP BY sp.IDSP, sp.MaSP, sp.TenSP, sp.GiaSP, dm.TenDM, sp.HinhAnh, sp.TrangThai";

        ArrayList<Model_SanPham> list = new ArrayList<>();

        try (
                Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // Thực thi truy vấn
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt(1);
                String ma = rs.getString(2);
                String ten = rs.getString(3);
                double giaBan = rs.getDouble(4);
                String tendm = rs.getString(5);
                String hinhAnh = rs.getString(6);
                int trangThai = rs.getInt(7);
                int tonKho = rs.getInt(8);
                Model_SanPham sp = new Model_SanPham(id, ma, ten, giaBan, tendm, hinhAnh, trangThai, tonKho);

                list.add(sp);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }

    }
    public ArrayList<Model_nguyenLieuChiTiet> getListNLCT_them(int IDSP) {
    // Tạo câu SQL
    String sql = "SELECT IDSP, IDNL, SoLuongSuDung, MoTa FROM NguyenLieuChiTiet WHERE IDSP = ?";

    ArrayList<Model_nguyenLieuChiTiet> list = new ArrayList<>();

    try (
        Connection conn = DBConnect.getConnection(); 
        PreparedStatement ps = conn.prepareStatement(sql)
    ) {
        // Đặt tham số
        ps.setObject(1, IDSP);
        
        // Thực thi truy vấn
        ResultSet rs = ps.executeQuery();
        
        while (rs.next()) {
            int maSp = rs.getInt(1);
            int maNl = rs.getInt(2);
            float luotDung = rs.getFloat(3);
            String moTa = rs.getString(4);
            Model_nguyenLieuChiTiet nlCt = new Model_nguyenLieuChiTiet(maSp, maNl, luotDung, moTa);

            list.add(nlCt);
        }
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
    return list;
}
    public ArrayList<Model_SanPham> TimKiemCbo(String ten) {
        // Tạo câu SQL
        String sql = """
                     SELECT DISTINCT
                         sp.MaSP,
                         sp.TenSP,
                         dm.TenDM,
                         sp.GiaSP,
                         nl.SoLuong,
                     	sp.TrangThai
                         
                     FROM 
                         SanPham sp
                                      INNER JOIN DanhMuc dm ON sp.IDDM = dm.IDDM 
                                      LEFT JOIN NguyenLieuChiTiet nlct ON nlct.IDSP = sp.IDSP
                                      LEFT JOIN NguyenLieu nl ON nl.IDNL = nlct.IDNL
                     WHERE
                         dm.TenDM LIKE ?
                     """;

        ArrayList<Model_SanPham> list = new ArrayList<>();

        try (
                Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // Thực thi truy vấn
            ResultSet rs = ps.executeQuery();
            ps.setObject(1, "%" + ten + "%");
            while (rs.next()) {

                String masp = rs.getString(1);
                String tensp = rs.getString(2);
                String Tendm = rs.getString(3);
                double giaban = rs.getDouble(4);
                int soluong = rs.getInt(5);
                int trangthai = rs.getInt(6);

                Model_SanPham sp = new Model_SanPham(masp, tensp, giaban, soluong, Tendm,trangthai);
                list.add(sp);

            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public ArrayList<Model_DanhMuc> getDanhMucSp() {
        sql = "select IDDM,MaDM,TenDM,TrangThai from DanhMuc";
        ArrayList<Model_DanhMuc> listDM = new ArrayList<>();
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {

                Model_DanhMuc dm = new Model_DanhMuc(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getBoolean(4));
                listDM.add(dm);
            }
            return listDM;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
