/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Repository;

import Config.DBConnect;
import Entity.Model_DanhMuc;
import Entity.Model_HoaDon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import Entity.Model_HoaDonChiTiet;
import Entity.Model_SanPham;

/**
 *
 * @author Dell
 */
public class Reporitories_BanHang {
    private Connection con =null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private String sql=null;
    
    public ArrayList<Model_SanPham> getListSp() {
        // Tạo câu SQL
        String sql = "SELECT sp.IDSP, sp.MaSP, sp.TenSP, sp.GiaSP, dm.TenDM, sp.HinhAnh, sp.TrangThai, "
                + "COALESCE(MIN(CASE WHEN nl.SoLuong / nlct.SoLuongSuDung < 1 THEN 0 ELSE FLOOR(nl.SoLuong / nlct.SoLuongSuDung) END), 0) AS SoLuongTonKho "
                + "FROM SanPham sp "
                + "INNER JOIN DanhMuc dm ON sp.IDDM = dm.IDDM "
                + "LEFT JOIN NguyenLieuChiTiet nlct ON nlct.IDSP = sp.IDSP "
                + "LEFT JOIN NguyenLieu nl ON nl.IDNL = nlct.IDNL "
                + "GROUP BY sp.IDSP, sp.MaSP, sp.TenSP, sp.GiaSP, dm.TenDM, sp.HinhAnh, sp.TrangThai";

        ArrayList<Model_SanPham> list = new ArrayList<>();

        try (
                Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // Thực thi truy vấn
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int id = rs.getInt(1);
                String ma = rs.getString(2);
                String ten = rs.getString(3);
                double giaBan = rs.getDouble(4);
                String tendm = rs.getString(5);
                String hinhAnh = rs.getString(6);
                int trangThai = rs.getInt(7);
                int tonKho = rs.getInt(8);
                Model_SanPham sp = new Model_SanPham(id, ma, ten, giaBan, tendm, hinhAnh, trangThai, tonKho);

                list.add(sp);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public ArrayList<Model_SanPham> TimKiemCbo(String ten) {
        // Tạo câu SQL
        String sql = """
                     SELECT DISTINCT
                         sp.MaSP,
                         sp.TenSP,
                         dm.TenDM,
                         sp.GiaSP,
                         nl.SoLuong,
                     	sp.TrangThai
                         
                     FROM 
                         SanPham sp
                                      INNER JOIN DanhMuc dm ON sp.IDDM = dm.IDDM 
                                      LEFT JOIN NguyenLieuChiTiet nlct ON nlct.IDSP = sp.IDSP
                                      LEFT JOIN NguyenLieu nl ON nl.IDNL = nlct.IDNL
                     WHERE
                         dm.TenDM LIKE ?
                     """;

        ArrayList<Model_SanPham> list = new ArrayList<>();

        try (
                Connection conn = DBConnect.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            // Thực thi truy vấn
            ResultSet rs = ps.executeQuery();
            ps.setObject(1, "%" + ten + "%");
            while (rs.next()) {

                String masp = rs.getString(1);
                String tensp = rs.getString(2);
                String Tendm = rs.getString(3);
                double giaban = rs.getDouble(4);
                int soluong = rs.getInt(5);
                int trangthai = rs.getInt(6);

                Model_SanPham sp = new Model_SanPham(masp, tensp, giaban, soluong, Tendm, trangthai);
                list.add(sp);

            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public ArrayList<Model_DanhMuc> getDanhMuc() {
        sql = "select IDDM,MaDM,TenDM,TrangThai from DanhMuc";
        ArrayList<Model_DanhMuc> listDM = new ArrayList<>();
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {

                Model_DanhMuc dm = new Model_DanhMuc(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getBoolean(4));
                listDM.add(dm);
            }
            return listDM;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public ArrayList<Model_HoaDon> loadHoaDon(){
        sql="SELECT hd.IDHD, hd.MaHD, hd.NgayTao, nv.HoTen, \n" +
"   COALESCE(SUM(ct.SoLuong * ct.GiaBan), 0) AS 'Tổng tiền', -- Sử dụng COALESCE để xử lý trường hợp NULL\\n\" +\n" +
"    tb.TenBan,hd.TrangThai, \n" +
"    COALESCE(vc.PhanTramGiam, 0) AS PhanTramGiam, \n" +
"   kh.HoTen,kh.SDT,nv.MaNV,\n" +
"    COALESCE(SUM(ct.SoLuong * ct.GiaBan), 0) * (1 - COALESCE(vc.PhanTramGiam, 0) / 100.0) AS 'Tổng tiền cần thanh toán',vc.TenVC\n" +
"FROM HoaDon hd\n" +
"LEFT JOIN HoaDonChiTiet ct ON ct.IDHD = hd.IDHD\n" +
"INNER JOIN TheBan tb ON tb.IDTB = hd.IDBan\n" +
"INNER JOIN NhanVien nv ON nv.IDNV = hd.IDNV\n" +
"LEFT JOIN Voucher vc ON vc.IDVC = hd.IDVC\n" +
"LEFT JOIN KhachHang kh ON kh.IDKH = hd.IDKH\n" +
"WHERE hd.TrangThai = 0\n" +
"GROUP BY hd.IDHD,hd.MaHD, hd.NgayTao, nv.HoTen, tb.TenBan, hd.TrangThai, vc.PhanTramGiam, kh.HoTen, kh.SDT,nv.MaNV,vc.TenVC\n" +
"ORDER BY\n" +
"    CASE WHEN hd.TrangThai = 0 THEN 0 ELSE 1 END,\n" +
"    hd.NgayTao DESC;";
        ArrayList<Model_HoaDon> list = new ArrayList<>();
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                int id,phanTramGiamGia;
                String MaHD,NgayTao,HoTenNV,TenBan,HoTenKhachHang,SDTKH,MaNV;
                Boolean trangThai,HinhThucTT;
                double TongTien;
                
                
                id=rs.getInt(1);
                phanTramGiamGia=rs.getInt(8);
                
                
                MaHD=rs.getString(2);
                NgayTao=rs.getString(3);
                HoTenNV=rs.getString(4);
                TenBan=rs.getString(6);
                HoTenKhachHang=rs.getString(9);
                SDTKH=rs.getString(10);
                MaNV=rs.getString(11);
                
                
                TongTien=rs.getDouble(5);
                trangThai=rs.getBoolean(7);
                double TongCong=rs.getInt(12);
                String TenVC=rs.getString(13);
                
                Model_HoaDon hd = new Model_HoaDon(id, MaHD, TongTien, TenBan, HoTenNV, trangThai, NgayTao, MaNV, phanTramGiamGia, HoTenKhachHang, SDTKH,TongCong,TenVC);
                //ublic Model_HoaDon(int IDHD, String ma, double TongTien, String TenBan, String TenNhanVien, boolean TrangThai, String NgayTao, String MaNV, int PhanTramGiamGia, String TenKhachHang, String SDTKH) {
                list.add(hd);
                
            }
            return list;
            
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public Model_HoaDon getVoucherAndKhachHang(int IDHD){
        sql = "SELECT COALESCE(IDVC, 0) AS IDVC, IDKH FROM HoaDon WHERE IDHD = ?";
        Model_HoaDon hd = null;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setObject(1, IDHD);
            rs = ps.executeQuery(); // Thêm dòng này để thực thi câu truy vấn
            while(rs.next()){
                hd = new Model_HoaDon(rs.getInt("IDVC"), rs.getInt("IDKH"));
            }
            return hd;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }  
    public int TaoHoaDonMoi(Model_HoaDon hdn){
        System.out.println(hdn.getIDBan());
        System.out.println(hdn.getIdNV());
        System.out.println(hdn.getIDvoucher());
        System.out.println(hdn.getIDKH());

        String sqlTaoHD;
        boolean coVC = hdn.getIDvoucher() != -1;

        if(coVC){
            sqlTaoHD = "INSERT INTO HoaDon (IDBan, IDNV, IDKH, IDVC) VALUES (?, ?, ?, ?)";
        } else {
            sqlTaoHD = "INSERT INTO HoaDon (IDBan, IDNV, IDKH) VALUES (?, ?, ?)";
        }

        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sqlTaoHD);
            ps.setObject(1, hdn.getIDBan());
            ps.setObject(2, hdn.getIdNV());
            ps.setObject(3, hdn.getIDKH());
            if (coVC) {
                ps.setObject(4, hdn.getIDvoucher());
            }
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int TimKiemKhachHang(String ten, String sdt){
        // Model_HoaDon do model hóa đơn có đủ tên và sdt khách hàng 
        String sqlTimKH="SELECT IDKH FROM KhachHang WHERE SDT = ? OR HoTen = ?";
        Model_HoaDon kh= null;
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sqlTimKH);
            ps.setObject(1, ten);
            ps.setObject(2, sdt);
            rs=ps.executeQuery();
            while(rs.next()){
                kh= new Model_HoaDon(rs.getInt(1), ten, sdt);
            }
            return kh.getIDKH();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int ThemKH(String ten, String sdt) {
    String sqlThemKH = "INSERT INTO KhachHang (HoTen, SDT) VALUES (?, ?)";
    int idKh = 0;
    try {
        con = DBConnect.getConnection();
        ps = con.prepareStatement(sqlThemKH, Statement.RETURN_GENERATED_KEYS);
        ps.setObject(1, ten);
        ps.setObject(2, sdt);

        int affectedRows = ps.executeUpdate();  // Thực thi câu lệnh INSERT

        if (affectedRows == 0) {
            throw new SQLException("Tạo khách hàng thất bại, không có hàng nào bị ảnh hưởng.");
        }

        try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
            if (generatedKeys.next()) {
                idKh = generatedKeys.getInt(1);
            } else {
                throw new SQLException("Tạo khách hàng thất bại, không lấy được ID.");
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
        return 0;
    } finally {
        try {
            if (ps != null) ps.close();
            if (con != null && !con.isClosed()) con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    return idKh;
}

    
    public int ModuleTaoHoaDon(Model_HoaDon hd) {
        int idKH;
        if ((hd.getTenKhachHang() == null || hd.getTenKhachHang().trim().isEmpty()) && (hd.getSDTKH() == null || hd.getSDTKH().trim().isEmpty())) {
            idKH = ThemKH("Khách lẻ", null);
        } else {
            idKH = TimKiemKhachHang(hd.getTenKhachHang(), hd.getSDTKH());
            if (idKH == 0) {
                idKH = ThemKH(hd.getTenKhachHang(), hd.getSDTKH());
            } else {
    //            idKH = kh.getIDKH();
            }
        }
        //Model_HoaDon hdMoi = new Model_HoaDon(hd.getIDBan(), hd.getIdNV(), idKH, hd.getIDvoucher());
        Model_HoaDon hdMoi = new Model_HoaDon(hd.getIDvoucher(), hd.getIDBan(),idKH,hd.getIdNV());
        return TaoHoaDonMoi(hdMoi);
    }
    
    
    
    
    
    
    public ArrayList<Model_HoaDonChiTiet> getHoaDonChiTiet(int idHD){
        sql="select sp.TenSP,ct.SoLuong,ct.GiaBan,ct.MoTa,ct.IDSP from HoaDonChiTiet ct\n" +
"inner join SanPham sp on sp.IDSP=ct.IDSP\n" +
"where IDHD = ?";
        ArrayList<Model_HoaDonChiTiet> list = new ArrayList<>();
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, idHD);
            rs=ps.executeQuery();
            while(rs.next()){
                
                Model_HoaDonChiTiet ct = new Model_HoaDonChiTiet(rs.getInt(2),rs.getDouble(3),rs.getString(4),rs.getString(1),rs.getInt(5));
                list.add(ct);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public int XoaSanPhamChiTiet(int IDHD,int IDSP){
        sql="delete HoaDonChiTiet where IDSP = ? and IDHD =?";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, IDSP);
            ps.setObject(2, IDHD);         
            System.out.println("IDSP"+IDSP);
            System.out.println("IDHD"+IDHD);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    
    
    public int ThemSanPhamVaoHoaDon(int IDHD,int IDSP,int SoLuong,String MoTa){
        sql="insert into HoaDonChiTiet (IDHD,IDSP,SoLuong,MoTa) values (?,?,?,?)";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, IDHD);
            ps.setObject(2, IDSP);
            ps.setObject(3, SoLuong);
            ps.setObject(4, MoTa);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    public int ThanhToanHoaDon(int IDHD, double TongTienCanThanhToan){
        sql="update HoaDon set TrangThai = 1 , TongTien =? where IDHD = ?";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(2, IDHD);
            ps.setObject(1, TongTienCanThanhToan);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int TruVoucher(int IDVC){
        sql="update Voucher set SoLuong = SoLuong-1 where IDVC =?";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, IDVC);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
    public int UpdateKhachHang(String ten,String sdt, int IDKH){
        sql="update KhachHang set HoTen = ?, SDT =? where IDKH = ?";
        try {
            con=DBConnect.getConnection();
            ps=con.prepareStatement(sql);
            ps.setObject(1, ten);
            ps.setObject(2, sdt);
            ps.setObject(3, IDKH);
            return ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }   
    
    
    
    public void UpdateNguyenLieu(int IDSP, int SoLuong) {
        String sql = "exec UpdateNguyenLieu ?,?";
        try {
            con = DBConnect.getConnection();
            CallableStatement cs = con.prepareCall(sql);
            cs.setInt(1, IDSP);
            cs.setInt(2, SoLuong);
            cs.execute();
    //        cs.close();
    //        con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public Model_HoaDon getHoaDonShow(int IDHD) {
        String sql = "SELECT hd.IDHD, hd.MaHD, hd.NgayTao, nv.HoTen, \n" +
                    "   COALESCE(SUM(ct.SoLuong * ct.GiaBan), 0) AS 'Tổng tiền', -- Sử dụng COALESCE để xử lý trường hợp NULL\\\\n\\\" +\n" +
                    "    tb.TenBan,hd.TrangThai, \n" +
                    "   COALESCE(vc.PhanTramGiam, 0) AS PhanTramGiam, \n" +
                    "   kh.HoTen,kh.SDT,nv.MaNV,\n" +
                    "   COALESCE(SUM(ct.SoLuong * ct.GiaBan), 0) * (1 - COALESCE(vc.PhanTramGiam, 0) / 100.0) AS 'Tổng tiền cần thanh toán',vc.TenVC\n" +
                    "FROM HoaDon hd\n" +
                    "LEFT JOIN HoaDonChiTiet ct ON ct.IDHD = hd.IDHD\n" +
                    "INNER JOIN TheBan tb ON tb.IDTB = hd.IDBan\n" +
                    "INNER JOIN NhanVien nv ON nv.IDNV = hd.IDNV\n" +
                    "LEFT JOIN Voucher vc ON vc.IDVC = hd.IDVC\n" +
                    "LEFT JOIN KhachHang kh ON kh.IDKH = hd.IDKH\n" +
                    "WHERE hd.IDHD=?\n" +
                    "GROUP BY hd.IDHD,hd.MaHD, hd.NgayTao, nv.HoTen, tb.TenBan, hd.TrangThai, vc.PhanTramGiam, kh.HoTen, kh.SDT,nv.MaNV,vc.TenVC\n" +
                    "ORDER BY\n" +
                    "    CASE WHEN hd.TrangThai = 0 THEN 0 ELSE 1 END,\n" +
                    "    hd.NgayTao DESC;";
        Model_HoaDon hd = null;
        try {
            con = DBConnect.getConnection();
            ps = con.prepareStatement(sql);
            ps.setInt(1,IDHD);
            rs = ps.executeQuery();
            if (rs.next()) {
                int id = rs.getInt(1);
                String MaHD = rs.getString(2);
                String NgayTao = rs.getString(3);
                String HoTenNV = rs.getString(4);
                double TongTien = rs.getDouble(5);
                String TenBan = rs.getString(6);
                boolean trangThai = rs.getBoolean(7);
                int phanTramGiamGia = rs.getInt(8);
                String HoTenKhachHang = rs.getString(9);
                String SDTKH = rs.getString(10);
                String MaNV = rs.getString(11);
                double TongCong = rs.getDouble(12);
                String TenVC = rs.getString(13);

                hd = new Model_HoaDon(id, MaHD, TongTien, TenBan, HoTenNV, trangThai, NgayTao, MaNV, phanTramGiamGia, HoTenKhachHang, SDTKH, TongCong, TenVC);
                System.out.println("MAHD REPO: " + hd.getIDHD());
            }
            return hd;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            // Đảm bảo đóng các kết nối, statement và result set
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    

}
