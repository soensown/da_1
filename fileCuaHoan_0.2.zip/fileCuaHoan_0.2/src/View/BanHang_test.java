


/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package View;

import Entity.Model_DanhMuc;
import javax.swing.table.DefaultTableModel;
import Repository.Reporitories_BanHang;
import Repository.Repositories_QuanLySanPham;
import Entity.Model_HoaDon;
import Entity.Model_SanPham;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Entity.Model_User;
import Entity.Model_Voucher;
import javax.swing.DefaultComboBoxModel;
import Repository.Repositories_Voucher;
import Entity.Model_TheBan;
import Repository.Repositories_TheBan;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Entity.Model_HoaDonChiTiet;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import Service.Service_BanHang;
import Service.Service_LichSuDon;
import Service.Service_Login;
import Service.Service_QuanLyNguyenLieu;
import Service.Service_QuanLySanPham;
import Service.Service_Start;
import Service.Service_TheBan;
import Service.Service_ThongKe;
import Service.Service_Voucher;

/**
 *
 * @author Dell
 */
public class BanHang_test extends javax.swing.JInternalFrame {
    private DefaultTableModel mol = new DefaultTableModel();
    private Reporitories_BanHang rp = new Reporitories_BanHang();
    private Repositories_QuanLySanPham rpsp = new Repositories_QuanLySanPham();
    private Repositories_Voucher rpvc = new Repositories_Voucher();
    private Repositories_TheBan rptb = new Repositories_TheBan();
    
    
    private Service_BanHang svbh = new Service_BanHang(); 
    
    private int HoaDonDuocChon= -1;
    private int i = -1;

    /**
     * Creates new form View_BanHang
     */
    public BanHang_test(Model_User user) {
        initComponents();
        this.loadData(svbh.loadHoaDon());
        this.LoadSp(rpsp.getListSp());
        cbo_Voucher.removeAllItems();
        cbo_TenBan.removeAllItems();
        this.loadCboTheBan(rptb.getTheBan());
        this.loadCboVoucher(rpvc.getVoucher());
        System.out.println("ID là    "+user.getIDNV());
        Label_IDNV.setText(String.valueOf(user.getIDNV()));
        Label_TenNV.setText(user.getTenNV());
        this.loadDanhSachBan(rptb.getTheBan());
        
    }    
    public void loadData(ArrayList<Model_HoaDon> m){
        mol=(DefaultTableModel)tbl_HoaDon.getModel();
        mol.setRowCount(0);
        for(Model_HoaDon x:m){
            mol.addRow(x.toDataRowHoaDon());
        }
        
    }
    public void LoadSp(ArrayList<Model_SanPham> list){
        mol=(DefaultTableModel)tbl_SanPham.getModel();
        mol.setRowCount(0);
        for(Model_SanPham x:list){
            mol.addRow(x.toDataRowBH());
        }
    }
    public void loadCboVoucher(ArrayList<Model_Voucher> list) {
        DefaultComboBoxModel cbm = (DefaultComboBoxModel) cbo_Voucher.getModel();
        for (Model_Voucher vc : list) {
            cbm.addElement(vc);
        }
    }
    public void loadCboTheBan(ArrayList<Model_TheBan> listB) {
        DefaultComboBoxModel cbm = (DefaultComboBoxModel) cbo_TenBan.getModel();
        for (Model_TheBan vc : listB) {
            cbm.addElement(vc);
        }
    }
    public void loadHDCT(ArrayList<Model_HoaDonChiTiet> list){
        mol=(DefaultTableModel)tbl_HoaDonChiTiet.getModel();
        mol.setRowCount(0);
        for(Model_HoaDonChiTiet x:list){
            mol.addRow(x.toDataHDCT());
        }
    }
    public void loadDanhSachBan(ArrayList<Model_TheBan> listB) {
        // Xóa tất cả các thành phần hiện tại trong Panel_DanhSachBan
        Panel_DanhSachBan.removeAll();

        // Thiết lập layout cho Panel_DanhSachBan (GridLayout)
        Panel_DanhSachBan.setLayout(new GridLayout(0, 4, 10, 10)); // 4 cột, khoảng cách 10px

        // Duyệt qua danh sách các bàn và tạo các JButton hoặc JPanel tương ứng
        for (Model_TheBan ban : listB) {
            JButton btnBan = new JButton(ban.getTenBan());
            btnBan.setPreferredSize(new Dimension(100, 100));
            btnBan.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Xử lý sự kiện khi nhấn vào bàn
                    System.out.println("Bạn đã chọn: " + ban.getTenBan());
                    // Ở đây bạn có thể thêm logic để hiển thị thông tin hóa đơn của bàn này
                }
            });

            // Thêm JButton vào Panel_DanhSachBan
            Panel_DanhSachBan.add(btnBan);
        }

        // Cập nhật giao diện
        Panel_DanhSachBan.revalidate();
        Panel_DanhSachBan.repaint();
    }

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txt_tenKh = new javax.swing.JTextField();
        txt_SDT = new javax.swing.JTextField();
        Label_TongTienHang = new javax.swing.JLabel();
        Label_MaHD = new javax.swing.JLabel();
        Lable_MaNV = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_HoaDonChiTiet = new javax.swing.JTable();
        btn_ThanhToan = new javax.swing.JButton();
        cbo_Voucher = new javax.swing.JComboBox<>();
        cbo_TenBan = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Label_IDHD = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Label_TongCong = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Label_TienGiamVoucher = new javax.swing.JLabel();
        btn_TaoHoaDon = new javax.swing.JButton();
        Label_IDNV = new javax.swing.JLabel();
        btn_LamMoiHoaDon = new javax.swing.JButton();
        Label_TenNV = new javax.swing.JLabel();
        Menu_PhongBan = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_SanPham = new javax.swing.JTable();
        jPanel9 = new javax.swing.JPanel();
        txt_SearchTen3 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        btn_Search3 = new javax.swing.JButton();
        cbo_FindDanhMuc3 = new javax.swing.JComboBox<>();
        cbo_FindTrangThai3 = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_HoaDon = new javax.swing.JTable();
        Panel_DanhSachBan = new javax.swing.JPanel();

        setPreferredSize(new java.awt.Dimension(1200, 700));

        jPanel1.setPreferredSize(new java.awt.Dimension(1200, 670));

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setText("Thành tiền");

        jLabel8.setText("SDT:");

        jLabel10.setText("Khách hàng:");

        Label_TongTienHang.setText("$$");

        Label_MaHD.setText("MaHD");

        Lable_MaNV.setText("MaNV");

        tbl_HoaDonChiTiet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Sản phẩm", "Số lượng", "Đơn giá", "Mô tả"
            }
        ));
        jScrollPane2.setViewportView(tbl_HoaDonChiTiet);

        btn_ThanhToan.setText("Thanh toán");
        btn_ThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ThanhToanActionPerformed(evt);
            }
        });

        cbo_Voucher.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbo_Voucher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_VoucherActionPerformed(evt);
            }
        });

        cbo_TenBan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel11.setText("Số bàn:");

        jLabel2.setText("Voucher");

        Label_IDHD.setText("IDHD");

        jLabel6.setText("ID:");

        jLabel4.setText("Tổng tiền");

        Label_TongCong.setText("$$");

        jLabel7.setText("Voucher");

        Label_TienGiamVoucher.setText("$$");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Lable_MaNV)
                            .addComponent(Label_MaHD)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(2, 2, 2)
                                .addComponent(Label_IDHD)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(18, 18, 18)
                        .addComponent(cbo_TenBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel4)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(txt_tenKh, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbo_Voucher, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(Label_TongCong, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                        .addComponent(btn_ThanhToan)
                        .addGap(24, 24, 24))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Label_TienGiamVoucher, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Label_TongTienHang, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_IDHD)
                    .addComponent(jLabel6))
                .addGap(4, 4, 4)
                .addComponent(Label_MaHD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Lable_MaNV)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbo_TenBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(cbo_Voucher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txt_tenKh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Label_TongTienHang, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_ThanhToan))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Label_TienGiamVoucher, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Label_TongCong, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        btn_TaoHoaDon.setText("Tạo hóa đơn");
        btn_TaoHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TaoHoaDonActionPerformed(evt);
            }
        });

        Label_IDNV.setText("ID");

        btn_LamMoiHoaDon.setText("Làm mới ");
        btn_LamMoiHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LamMoiHoaDonActionPerformed(evt);
            }
        });

        Label_TenNV.setText("TênNV");

        tbl_SanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên sản phẩm", "Danh mục", "Giá sản phẩm"
            }
        ));
        tbl_SanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_SanPhamMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_SanPham);

        jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setText("Tên sản phẩm");

        btn_Search3.setText("Tìm kiếm");

        cbo_FindDanhMuc3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbo_FindDanhMuc3.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbo_FindDanhMuc3ItemStateChanged(evt);
            }
        });

        cbo_FindTrangThai3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setText("Danh mục");

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setText("Trạng thái");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(txt_SearchTen3)))
                .addGap(45, 45, 45)
                .addComponent(btn_Search3)
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbo_FindDanhMuc3, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                    .addComponent(cbo_FindTrangThai3, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_Search3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbo_FindDanhMuc3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbo_FindTrangThai3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                        .addComponent(txt_SearchTen3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 429, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Menu_PhongBan.addTab("Thực đơn", jPanel4);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/NhanVien.png"))); // NOI18N
        jLabel3.setText("tất cả");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/NhanVien.png"))); // NOI18N
        jLabel20.setText("Đang sử dụng");
        jLabel20.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/NhanVien.png"))); // NOI18N
        jLabel1.setText("Trống");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 215, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(57, 57, 57))
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addGap(196, 196, 196)
                    .addComponent(jLabel20)
                    .addContainerGap(225, Short.MAX_VALUE)))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel8Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        tbl_HoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "IDHD", "Ngày tạo", "Người tạo", "Tổng tiền hàng", "Tổng cộng", "Bàn", "Trạng thái"
            }
        ));
        tbl_HoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_HoaDonMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_HoaDon);

        Panel_DanhSachBan.setBorder(new javax.swing.border.MatteBorder(null));

        javax.swing.GroupLayout Panel_DanhSachBanLayout = new javax.swing.GroupLayout(Panel_DanhSachBan);
        Panel_DanhSachBan.setLayout(Panel_DanhSachBanLayout);
        Panel_DanhSachBanLayout.setHorizontalGroup(
            Panel_DanhSachBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        Panel_DanhSachBanLayout.setVerticalGroup(
            Panel_DanhSachBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 304, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 107, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Panel_DanhSachBan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Panel_DanhSachBan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        Menu_PhongBan.addTab("Phòng bàn", jPanel3);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Menu_PhongBan, javax.swing.GroupLayout.PREFERRED_SIZE, 709, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_LamMoiHoaDon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_TaoHoaDon)
                        .addGap(46, 46, 46)
                        .addComponent(Label_IDNV)
                        .addGap(18, 18, 18)
                        .addComponent(Label_TenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(11, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_LamMoiHoaDon)
                    .addComponent(btn_TaoHoaDon)
                    .addComponent(Label_IDNV)
                    .addComponent(Label_TenNV))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(81, 81, 81))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(Menu_PhongBan, javax.swing.GroupLayout.PREFERRED_SIZE, 666, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbo_VoucherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_VoucherActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbo_VoucherActionPerformed

    private void btn_LamMoiHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LamMoiHoaDonActionPerformed
        // TODO add your handling code here:
        int choice = JOptionPane.showConfirmDialog(null, "Xác nhận làm mới hóa đơn", "Làm mới hóa đơn", JOptionPane.OK_CANCEL_OPTION);
        
        if (choice == JOptionPane.OK_OPTION) {
            txt_SDT.setText(null);
            txt_tenKh.setText(null);
            Label_TongTienHang.setText(null);
            Label_MaHD.setText(null);
            Lable_MaNV.setText(null);
            
        } else {
            // Người dùng chọn Cancel hoặc đóng cửa sổ dialog
            System.out.println("Đã chọn Cancel hoặc đóng cửa sổ dialog.");
        }
    }//GEN-LAST:event_btn_LamMoiHoaDonActionPerformed

    private void btn_TaoHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TaoHoaDonActionPerformed
        // TODO add your handling code here:
        if(svbh.ModuleTaoHoaDon(getForm())!=0){
            JOptionPane.showMessageDialog(this, "Thêm thành công");
            this.loadData(svbh.loadHoaDon());
        }else{
            JOptionPane.showMessageDialog(this, "Thêm thất bại");
        }
    }//GEN-LAST:event_btn_TaoHoaDonActionPerformed

    private void btn_ThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ThanhToanActionPerformed
        // TODO add your handling code here:
        HoaDonDuocChon=tbl_HoaDon.getSelectedRow();
        Model_HoaDon hd = svbh.loadHoaDon().get(HoaDonDuocChon);
        int idhd = Integer.parseInt(Label_IDHD.getText());
        double tongTienTT = Double.parseDouble(Label_TongCong.getText());
        if(HoaDonDuocChon<0){
            JOptionPane.showMessageDialog(this, "Chưa chọn hóa đơn nào ");
        }
        if(svbh.ThanhToanHoaDon(idhd,tongTienTT)!=0){
            if(hd.getIDvoucher()!=0){
                svbh.TruVoucher(hd.getIDvoucher());
            }            
            svbh.UpdateKhachHang(txt_tenKh.getText(),txt_SDT.getText(), hd.getIDKH());
            JOptionPane.showMessageDialog(this, "Thanh toán hóa đơn thành công");
            this.loadData(svbh.loadHoaDon());
            txt_SDT.setText(null);
            txt_tenKh.setText(null);
            Label_TongTienHang.setText(null);
            Label_MaHD.setText(null);
            Lable_MaNV.setText(null);           
        }
    }//GEN-LAST:event_btn_ThanhToanActionPerformed

    private void tbl_HoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_HoaDonMouseClicked
        // TODO add your handling code here:
        HoaDonDuocChon=tbl_HoaDon.getSelectedRow();
        if (HoaDonDuocChon < 0) {
            JOptionPane.showMessageDialog(null, "Không có hóa đơn nào được chọn", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Model_HoaDon hd = svbh.loadHoaDon().get(HoaDonDuocChon);
        Label_IDHD.setText(String.valueOf(hd.getIDHD()));
        this.loadHDCT(svbh.getHoaDonChiTiet(hd.getIDHD()));
        ShowHoaDon(HoaDonDuocChon);
    }//GEN-LAST:event_tbl_HoaDonMouseClicked

    private void cbo_FindDanhMuc3ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbo_FindDanhMuc3ItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_cbo_FindDanhMuc3ItemStateChanged

    private void tbl_SanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_SanPhamMouseClicked
        // TODO add your handling code here:

        int i = tbl_SanPham.getSelectedRow();
        int soLuong = 0;
        Model_SanPham sp=rpsp.getListSp().get(i);
        // Tạo panel để chứa các input fields

        String input = JOptionPane.showInputDialog(null, "Nhập số lượng sản phẩm:", "Nhập số lượng", JOptionPane.PLAIN_MESSAGE);
        int IDHD = Integer.parseInt(Label_IDHD.getText());
        if (input == null) {
            JOptionPane.showMessageDialog(null, "Thao tác đã bị hủy", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            soLuong = Integer.parseInt(input);
            if (soLuong <= 0) {
                JOptionPane.showMessageDialog(null, "Số lượng phải lớn hơn 0", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Vui lòng nhập số lượng hợp lệ", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String MoTa = JOptionPane.showInputDialog(null, "Nhập mô tả sản phẩm (chú thích):", "Nhập mô tả", JOptionPane.PLAIN_MESSAGE);

        if (MoTa == null) {
            JOptionPane.showMessageDialog(null, "Thao tác đã bị hủy", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            svbh.ThemSanPhamVaoHoaDon(IDHD,sp.getIDSP(), soLuong,MoTa);
            this.loadHDCT(svbh.getHoaDonChiTiet(IDHD));
            this.loadData(svbh.loadHoaDon());
            int idhd = Integer.parseInt(Label_IDHD.getText());
            System.out.println("IDHD la+ "+i);
            //this.ShowHoaDon(idhd);System.out.println("IDHD la+ " + IDHD);
            if (HoaDonDuocChon != -1) {
                ShowHoaDon(HoaDonDuocChon); // Gọi hàm ShowHoaDon với chỉ số hóa đơn hiện tại
            }
            JOptionPane.showMessageDialog(null, "Thêm sản phẩm vào hóa đơn thành công", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Có lỗi xảy ra khi thêm sản phẩm vào hóa đơn", "Lỗi", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_tbl_SanPhamMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Label_IDHD;
    private javax.swing.JLabel Label_IDNV;
    private javax.swing.JLabel Label_MaHD;
    private javax.swing.JLabel Label_TenNV;
    private javax.swing.JLabel Label_TienGiamVoucher;
    private javax.swing.JLabel Label_TongCong;
    private javax.swing.JLabel Label_TongTienHang;
    private javax.swing.JLabel Lable_MaNV;
    private javax.swing.JTabbedPane Menu_PhongBan;
    private javax.swing.JPanel Panel_DanhSachBan;
    private javax.swing.JButton btn_LamMoiHoaDon;
    private javax.swing.JButton btn_Search3;
    private javax.swing.JButton btn_TaoHoaDon;
    private javax.swing.JButton btn_ThanhToan;
    private javax.swing.JComboBox<String> cbo_FindDanhMuc3;
    private javax.swing.JComboBox<String> cbo_FindTrangThai3;
    private javax.swing.JComboBox<String> cbo_TenBan;
    private javax.swing.JComboBox<String> cbo_Voucher;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tbl_HoaDon;
    private javax.swing.JTable tbl_HoaDonChiTiet;
    private javax.swing.JTable tbl_SanPham;
    private javax.swing.JTextField txt_SDT;
    private javax.swing.JTextField txt_SearchTen3;
    private javax.swing.JTextField txt_tenKh;
    // End of variables declaration//GEN-END:variables

    public void ShowHoaDon(int i){
        Model_HoaDon hd = svbh.loadHoaDon().get(i);
        Model_Voucher vc = (Model_Voucher)cbo_Voucher.getSelectedItem();
        Label_MaHD.setText(hd.getMa());
        Lable_MaNV.setText(hd.getMaNV());
        Label_TongTienHang.setText(tbl_HoaDon.getValueAt(i, 3).toString());
        txt_SDT.setText(hd.getSDTKH());
        txt_tenKh.setText(hd.getTenKhachHang());       
        String tenVc=hd.getTenVC();
        DefaultComboBoxModel cbm = (DefaultComboBoxModel)cbo_Voucher.getModel();
        for (int j = 0; j < cbm.getSize(); j++) {
            Model_Voucher vch = (Model_Voucher) cbm.getElementAt(j);
            if (vch.getTenVC().equals(tenVc)) {
                cbo_Voucher.setSelectedIndex(j);
                break;
            }
        }    
        double tongTienHang = Double.parseDouble(tbl_HoaDon.getValueAt(i, 3).toString());     
        Label_TongCong.setText(tbl_HoaDon.getValueAt(i, 4).toString());
        if(vc!=null){
            Double GiamGia=(tongTienHang*(vc.getPhanTramGiamGia()/100.0))*-1;
            System.out.println("Tiền hàng"+tongTienHang+"Giảm giá"+GiamGia);
            Label_TienGiamVoucher.setText(String.valueOf(GiamGia)); 
        }
       
    }
    
    public Model_HoaDon getForm(){      
        Model_Voucher vc = (Model_Voucher)cbo_Voucher.getSelectedItem();
        Model_TheBan tb = (Model_TheBan)cbo_TenBan.getSelectedItem();       
        String sdt =txt_SDT.getText().trim();
        String tenKh =txt_tenKh.getText().trim();
        int IdNV=Integer.parseInt(Label_IDNV.getText());  
        int idvc = -1;
        //String vcher = String.valueOf(vc.getIdVC());
        if(vc!=null){
            idvc=vc.getIdVC();
        }        
        Model_HoaDon hd = new Model_HoaDon(idvc, tb.getIDBan(),tenKh, sdt, IdNV);
        return hd;
        //System.out.println("BAN DA DUOC CHON LA:"+tb.getIDBan());
                     
    }
}



