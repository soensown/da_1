/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package View;

import Entity.Model_SanPham;
import Repository.Repositories_QuanLySanPham;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import Entity.Model_DanhMuc;
import Entity.Model_NguyenLieu;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import Entity.Model_Voucher;
import Entity.Model_nguyenLieuChiTiet;
import Repository.Repositories_QuanLyNguyenLieuChiTiet;
import java.util.List;

/**
 *
 * @author Dell
 */
public class View_NguyenLieuChiTiet extends javax.swing.JInternalFrame {

    private Repositories_QuanLyNguyenLieuChiTiet rp = new Repositories_QuanLyNguyenLieuChiTiet();
    private Model_DanhMuc dm = new Model_DanhMuc();
    private DefaultTableModel mol = new DefaultTableModel();
    //private DefaultComboBoxModel cbo_model = new DefaultComboBoxModel();
    private int i = -1;

    /**
     * Creates new form View_SanPham
     */
    public View_NguyenLieuChiTiet() {
        initComponents();
        loadCategoryThuongHieu();
        LoadListSp(rp.getListSp());
        LoadListNl(rp.getListNL());
        tbl_SanPham.setRowSelectionInterval(0, 0);
        int row = this.tbl_SanPham.getSelectedRow();
        if (row == -1) {
            
            return;
        }
        Model_SanPham sp = rp.getListSp().get(row);
        txt_IDSP.setText(String.valueOf(sp.getIDSP()));
        txt_MaSp.setText(sp.getMaSP());
        txt_TenSanPham.setText(sp.getTenSP());
        this.LoadListNLCt_All(rp.getListNLCT_them(sp.getIDSP()));
        cbo_FindTrangThai.removeAllItems();
        cbo_FindTrangThai.addItem("Ngưng bán");
        cbo_FindTrangThai.addItem("Đang bán");
        cbo_FindTrangThaiNguyenLieu.removeAllItems();
        cbo_FindTrangThaiNguyenLieu.addItem("Ngưng bán");
        cbo_FindTrangThaiNguyenLieu.addItem("Đang bán");
        this.LoadListSp(rp.getListSp());
        this.loadCboFind(rp.getDanhMucSp());
    }

    public void LoadListSp(ArrayList<Model_SanPham> list) {
        mol = (DefaultTableModel) tbl_SanPham.getModel();
        mol.setRowCount(0);
        for (Model_SanPham x : list) {
            mol.addRow(x.toDataRow());
        }
    }

    public void LoadListNLCt_All(ArrayList<Model_nguyenLieuChiTiet> list) {
        mol = (DefaultTableModel) tbl_NguyenLieuChiTietAll.getModel();
        mol.setRowCount(0);
        for (Model_nguyenLieuChiTiet x : list) {
            mol.addRow(x.toDataRow());
        }
    }

    public void LoadListNLCtThem(ArrayList<Model_nguyenLieuChiTiet> list) {
        mol = (DefaultTableModel) tbl_NguyenLieuChiTietThem.getModel();
        mol.setRowCount(0);
        for (Model_nguyenLieuChiTiet x : list) {
            mol.addRow(x.toDataRow());
        }
    }

    public void LoadListNLCtThem1(ArrayList<Model_nguyenLieuChiTiet> list) {
        mol = (DefaultTableModel) tbl_NguyenLieuChiTietThem.getModel();
        mol.setRowCount(0);
        for (Model_nguyenLieuChiTiet x : list) {
            mol.addRow(x.toDataRow());
        }
    }

    public void LoadListNl(ArrayList<Model_NguyenLieu> list) {
        mol = (DefaultTableModel) tbl_NguyenLieu.getModel();
        mol.setRowCount(0);
        for (Model_NguyenLieu x : list) {
            mol.addRow(x.toDataRow());
        }
    }

    private void loadCategoryThuongHieu() {
        List<Model_DanhMuc> listDM = rp.getDanhMucSp();
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo_TenDoUong.getModel();
        if (!listDM.isEmpty()) {
            for (Model_DanhMuc dm : listDM) {
                model.addElement(dm.getTenDm());
            }
        }

    }

    public List<Model_SanPham> loadTableSpCt() {
        DefaultTableModel model = (DefaultTableModel) tbl_SanPham.getModel();

        model.setRowCount(0);

        List<Model_SanPham> list = new ArrayList<>();

        if (txt_SearchTen.getText().trim().isEmpty()) {
            list = rp.getListSp();
        } else {
            String tenSearch = txt_SearchTen.getText();
            list = rp.TimKiemCbo(tenSearch);
        }
        for (Model_SanPham sp : list) {
            model.addRow(new Object[]{
                sp.getMaSP(),
                sp.getTenSP(),
                sp.getTenDanhMuc(),
                sp.getGiaSP(),
                sp.getTonKho(),
                sp.getTrangThai() == 0 ? "Dang Ban" : "Ngung Ban",});

        }
        return list;
    }

    public void loadCboFind(ArrayList<Model_DanhMuc> list) {
        DefaultComboBoxModel cbm = (DefaultComboBoxModel) cbo_TenDoUong.getModel();
        for (Model_DanhMuc danhMuc : list) {
            cbm.addElement(danhMuc);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_SanPham = new javax.swing.JTable();
        jPanel5 = new javax.swing.JPanel();
        txt_SearchTen = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        btn_Search = new javax.swing.JButton();
        cbo_TenDoUong = new javax.swing.JComboBox<>();
        cbo_FindTrangThai = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_NguyenLieu = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_NguyenLieuChiTietAll = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_NguyenLieuChiTietThem = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_IDSP = new javax.swing.JLabel();
        txt_MaSp = new javax.swing.JLabel();
        txt_TenSanPham = new javax.swing.JLabel();
        bnt_themNguyenLieu = new javax.swing.JButton();
        btn_XoaNguyenLieu = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        txt_SearchNguyenLieu = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        btn_SearchNguyenLieu = new javax.swing.JButton();
        cbo_FindTrangThaiNguyenLieu = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        btn_SearchNguyenLieu1 = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1200, 700));

        jPanel1.setPreferredSize(new java.awt.Dimension(1200, 670));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 212, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 33, Short.MAX_VALUE)
        );

        jPanel3.setPreferredSize(new java.awt.Dimension(620, 670));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 620, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        tbl_SanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên sản phẩm", "Danh mục", "Giá bán", "Số lượng tk", "Trạng thái"
            }
        ));
        tbl_SanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_SanPhamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_SanPham);

        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setText("Tên sản phẩm");

        btn_Search.setText("Tìm kiếm");
        btn_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SearchActionPerformed(evt);
            }
        });

        cbo_TenDoUong.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ALL" }));
        cbo_TenDoUong.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbo_TenDoUongItemStateChanged(evt);
            }
        });

        cbo_FindTrangThai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Danh mục");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setText("Trạng thái");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(txt_SearchTen)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_Search)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbo_TenDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbo_FindTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(0, 22, Short.MAX_VALUE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_SearchTen, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbo_TenDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbo_FindTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        tbl_NguyenLieu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã Nguyên liệu ", "Tên nguyên liệu", "số lượng", "đơn vị ", "mô tả", "Trạng thái"
            }
        ));
        tbl_NguyenLieu.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_NguyenLieuMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_NguyenLieu);

        tbl_NguyenLieuChiTietAll.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã sản phẩm", "Mã nguyên liệu", "số lượng", "mô tả"
            }
        ));
        tbl_NguyenLieuChiTietAll.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_NguyenLieuChiTietAllMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_NguyenLieuChiTietAll);

        tbl_NguyenLieuChiTietThem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã sản phẩm", "Mã nguyên liệu", "số lượng", "mô tả"
            }
        ));
        tbl_NguyenLieuChiTietThem.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_NguyenLieuChiTietThemMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_NguyenLieuChiTietThem);

        jLabel1.setText("IDSP:");

        jLabel2.setText("mã sản phẩm:");

        jLabel3.setText("tên sản phẩm:");

        bnt_themNguyenLieu.setText("thêm");
        bnt_themNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnt_themNguyenLieuActionPerformed(evt);
            }
        });

        btn_XoaNguyenLieu.setText("xóa");
        btn_XoaNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_XoaNguyenLieuActionPerformed(evt);
            }
        });

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("tên nguyên liệu");

        btn_SearchNguyenLieu.setText("Tìm kiếm");
        btn_SearchNguyenLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SearchNguyenLieuActionPerformed(evt);
            }
        });

        cbo_FindTrangThaiNguyenLieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setText("Trạng thái");

        btn_SearchNguyenLieu1.setText("reload");
        btn_SearchNguyenLieu1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SearchNguyenLieu1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(txt_SearchNguyenLieu)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_SearchNguyenLieu)
                .addGap(26, 26, 26)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(cbo_FindTrangThaiNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_SearchNguyenLieu1)))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_SearchNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_SearchNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbo_FindTrangThaiNguyenLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_SearchNguyenLieu1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(96, 96, 96)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addGap(49, 49, 49)
                                        .addComponent(txt_IDSP, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txt_MaSp, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txt_TenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel2Layout.createSequentialGroup()
                                            .addComponent(bnt_themNguyenLieu)
                                            .addGap(18, 18, 18)
                                            .addComponent(btn_XoaNguyenLieu))))))
                        .addGap(44, 44, 44)))
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel2Layout.createSequentialGroup()
                    .addGap(16, 16, 16)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(734, Short.MAX_VALUE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txt_IDSP, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(txt_MaSp, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(txt_TenSanPham, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 231, Short.MAX_VALUE)
                        .addGap(311, 311, 311))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bnt_themNguyenLieu)
                            .addComponent(btn_XoaNguyenLieu))
                        .addGap(52, 186, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                    .addContainerGap(421, Short.MAX_VALUE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(41, 41, 41)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 665, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbl_SanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_SanPhamMouseClicked
        int rowSp = this.tbl_SanPham.getSelectedRow();
        if (rowSp == -1) {
            return;
        }
        int rowNl = this.tbl_NguyenLieu.getSelectedRow();
        if (rowNl == -1) {
            return;
        }
        Model_NguyenLieu nl = rp.getListNL().get(rowNl);
        Model_SanPham sp = rp.getListSp().get(rowSp);
        txt_IDSP.setText(String.valueOf(sp.getIDSP()));
        txt_MaSp.setText(sp.getMaSP());
        txt_TenSanPham.setText(sp.getTenSP());
        this.LoadListNLCt_All(rp.getListNLCT_them(sp.getIDSP()));

        Integer IDSP = sp.getIDSP();
        Integer IDNl = nl.getIDNL();
        String mota = sp.getTenSP() + "-" + nl.getTenNL();
        mol = (DefaultTableModel) tbl_NguyenLieuChiTietThem.getModel();
        mol.setRowCount(0);
        Object[] row = {
            IDSP, IDNl, 0, mota
        };
        mol.addRow(row);
    }//GEN-LAST:event_tbl_SanPhamMouseClicked

    private void cbo_TenDoUongItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbo_TenDoUongItemStateChanged
        // TODO add your handling code here:
        try {
            String Tendouong = cbo_TenDoUong.getSelectedItem().toString().trim();
            if (Tendouong.equalsIgnoreCase("All")) {
                LoadListSp(rp.getListSp());
            } else {
                DefaultTableModel model = (DefaultTableModel) tbl_SanPham.getModel();
                model.setRowCount(0);
                List<Model_SanPham> listLoc = new ArrayList<>();
                for (Model_SanPham sanPham : loadTableSpCt()) {
                    if (sanPham.getTenDanhMuc().equals(Tendouong)) {
                        listLoc.add(sanPham);
                    }
                    for (Model_SanPham x : loadTableSpCt()) {
                        mol.addRow(x.toDataRow());
                    }
                }
                model.setRowCount(0);
                for (Model_SanPham sp : listLoc) {
                    model.addRow(new Object[]{
                        sp.getMaSP(),
                        sp.getTenSP(),
                        sp.getTenDanhMuc(),
                        sp.getGiaSP(),
                        sp.getTonKho(),
                        sp.getTrangThai() == 0 ? "Dang Ban" : "Ngung Ban",});
                }
                if (listLoc.isEmpty()) {
                    model.setRowCount(0);
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cbo_TenDoUongItemStateChanged

    private void tbl_NguyenLieuChiTietThemMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_NguyenLieuChiTietThemMouseClicked
        // TODO add your handling code here:
        i = tbl_SanPham.getSelectedRow();
    }//GEN-LAST:event_tbl_NguyenLieuChiTietThemMouseClicked

    private void tbl_NguyenLieuMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_NguyenLieuMouseClicked
        // TODO add your handling code here:
        int rowSp = this.tbl_SanPham.getSelectedRow();
        if (rowSp == -1) {
            return;
        }
        int rowNl = this.tbl_NguyenLieu.getSelectedRow();
        if (rowNl == -1) {
            return;
        }
        Model_NguyenLieu nl = rp.getListNL().get(rowNl);
        Model_SanPham sp = rp.getListSp().get(rowSp);
        Integer IDSP = Integer.parseInt(txt_IDSP.getText());
        Integer IDNl = nl.getIDNL();
        String mota = sp.getTenSP() + "-" + nl.getTenNL();
        mol = (DefaultTableModel) tbl_NguyenLieuChiTietThem.getModel();
        mol.setRowCount(0);
        Object[] row = {
            IDSP, IDNl, 0, mota
        };
        mol.addRow(row);
    }//GEN-LAST:event_tbl_NguyenLieuMouseClicked

    private void tbl_NguyenLieuChiTietAllMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_NguyenLieuChiTietAllMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_NguyenLieuChiTietAllMouseClicked

    private void btn_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SearchActionPerformed
        // TODO add your handling code here:
        try {
            ArrayList<Model_SanPham> listM = new ArrayList<>();
            int trangThai = cbo_FindTrangThai.getSelectedIndex();
            String ten = txt_SearchTen.getText().trim();

            for (Model_SanPham sp : rp.getListSp()) {
                boolean matchTen = ten.isEmpty() || sp.getTenSP().equalsIgnoreCase(ten);
                boolean matchTrangThai = (trangThai == 0 && sp.getTrangThai() == 0) || (trangThai == 1 && sp.getTrangThai() == 1);

                if (matchTen && matchTrangThai) {
                    listM.add(sp);
                }
            }
            mol=(DefaultTableModel)this.tbl_SanPham.getModel();
            mol.setRowCount(0);
            for (Model_SanPham spm : listM) {
                Object[] row = {
                    spm.getMaSP(), spm.getTenSP(), spm.getTenDanhMuc(), spm.getGiaSP(), spm.getTonKho(), spm.getTrangThai() == 0 ? "ngưng bán" : "đang bán"
                };
                mol.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btn_SearchActionPerformed

    private void btn_SearchNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SearchNguyenLieuActionPerformed
        // TODO add your handling code here:
        try {
            ArrayList<Model_NguyenLieu> listM = new ArrayList<>();
            int trangThai = cbo_FindTrangThaiNguyenLieu.getSelectedIndex();
            String ten = txt_SearchNguyenLieu.getText().trim();

            for (Model_NguyenLieu sp : rp.getListNL()) {
                boolean matchTen = ten.isEmpty() || sp.getTenNL().equalsIgnoreCase(ten);
                boolean matchTrangThai = (trangThai == 0 && sp.getTrangThai() == 0) || (trangThai == 1 && sp.getTrangThai() == 1);

                if (matchTen && matchTrangThai) {
                    listM.add(sp);
                }
            }
            mol=(DefaultTableModel)this.tbl_NguyenLieu.getModel();
            mol.setRowCount(0);
            for (Model_NguyenLieu spm : listM) {
                Object[] row = {
                    spm.getMaNl(), spm.getTenNL(), spm.getSoLuong(), spm.getDonVi(), spm.getMoTa(), spm.getTrangThai() == 0 ? "ngưng bán" : "đang bán"
                };
                mol.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btn_SearchNguyenLieuActionPerformed

    private void btn_SearchNguyenLieu1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SearchNguyenLieu1ActionPerformed
        // TODO add your handling code here:
        LoadListNl(rp.getListNL());
    }//GEN-LAST:event_btn_SearchNguyenLieu1ActionPerformed

    private void bnt_themNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnt_themNguyenLieuActionPerformed
        // TODO add your handling code here:
        float soLuong = 0;
        String input = JOptionPane.showInputDialog(null, "Nhập số lượng sản phẩm:", "Nhập số lượng", JOptionPane.PLAIN_MESSAGE);
        if (input == null) {
            JOptionPane.showMessageDialog(null, "Thao tác đã bị hủy", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            soLuong = Integer.parseInt(input);
            if (soLuong <= 0) {
                JOptionPane.showMessageDialog(null, "Số lượng phải lớn hơn 0", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Vui lòng nhập số lượng hợp lệ", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        tbl_NguyenLieuChiTietThem.setRowSelectionInterval(0, 0);
        int row = tbl_NguyenLieuChiTietThem.getSelectedRow();
        if (row==-1) {
            JOptionPane.showMessageDialog(this, "không có dùng nào được chọn");
            return;
        }
        
        Integer IDSP = (Integer) this.tbl_NguyenLieuChiTietThem.getValueAt(row, 0);
        Integer IDNl = (Integer) this.tbl_NguyenLieuChiTietThem.getValueAt(row, 1);
        soLuong = Integer.parseInt(input);
        String mota = (String) this.tbl_NguyenLieuChiTietThem.getValueAt(row, 3);
        Model_nguyenLieuChiTiet nl = new Model_nguyenLieuChiTiet(IDSP, IDNl, soLuong, mota);
        
        if (rp.themNguyenLieuChiTiet(nl) != null) {
                JOptionPane.showMessageDialog(this, "thêm thành công");
                 this.LoadListNLCt_All(rp.getListNLCT_them(IDSP));
                 tbl_NguyenLieuChiTietThem.removeAll();
            } else {
                JOptionPane.showMessageDialog(this, "thêm không thành công");
            }
    }//GEN-LAST:event_bnt_themNguyenLieuActionPerformed

    private void btn_XoaNguyenLieuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_XoaNguyenLieuActionPerformed
        // TODO add your handling code here:
        int row = tbl_NguyenLieuChiTietAll.getSelectedRow();
        if (row==-1) {
            JOptionPane.showMessageDialog(this, "không có dùng nào được chọn");
            return;
        }
        Integer IDSP = Integer.parseInt(txt_IDSP.getText());
        Model_nguyenLieuChiTiet nl = rp.getListNLCT_them(IDSP).get(row);
        
        if (rp.XoaNguyenLieuChiTiet(nl.getIDSP(),nl.getIDNL())!=null) {
                JOptionPane.showMessageDialog(this, "xóa thành công");
                 this.LoadListNLCt_All(rp.getListNLCT_them(IDSP));
                 tbl_NguyenLieuChiTietThem.removeAll();
            } else {
                JOptionPane.showMessageDialog(this, "xóa không thành công");
            }
    }//GEN-LAST:event_btn_XoaNguyenLieuActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bnt_themNguyenLieu;
    private javax.swing.JButton btn_Search;
    private javax.swing.JButton btn_Search1;
    private javax.swing.JButton btn_SearchNguyenLieu;
    private javax.swing.JButton btn_SearchNguyenLieu1;
    private javax.swing.JButton btn_XoaNguyenLieu;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbo_FindTrangThai;
    private javax.swing.JComboBox<String> cbo_FindTrangThai1;
    private javax.swing.JComboBox<String> cbo_FindTrangThaiNguyenLieu;
    private javax.swing.JComboBox<String> cbo_TenDoUong;
    private javax.swing.JComboBox<String> cbo_TenDoUong1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable tbl_NguyenLieu;
    private javax.swing.JTable tbl_NguyenLieuChiTietAll;
    private javax.swing.JTable tbl_NguyenLieuChiTietThem;
    private javax.swing.JTable tbl_SanPham;
    private javax.swing.JLabel txt_IDSP;
    private javax.swing.JLabel txt_MaSp;
    private javax.swing.JTextField txt_SearchNguyenLieu;
    private javax.swing.JTextField txt_SearchTen;
    private javax.swing.JTextField txt_SearchTen1;
    private javax.swing.JLabel txt_TenSanPham;
    // End of variables declaration//GEN-END:variables

}
