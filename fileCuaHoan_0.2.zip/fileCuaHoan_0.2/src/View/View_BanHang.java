/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package View;

import Entity.Model_DanhMuc;
import javax.swing.table.DefaultTableModel;
import Repository.Reporitories_BanHang;
import Repository.Repositories_QuanLySanPham;
import Entity.Model_HoaDon;
import Entity.Model_SanPham;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import Entity.Model_User;
import Entity.Model_Voucher;
import javax.swing.DefaultComboBoxModel;
import Repository.Repositories_Voucher;
import Entity.Model_TheBan;
import Repository.Repositories_TheBan;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import Entity.Model_HoaDonChiTiet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import Service.Service_BanHang;
import Service.Service_LichSuDon;
import Service.Service_Login;
import Service.Service_QuanLyNguyenLieu;
import Service.Service_QuanLySanPham;
import Service.Service_Start;
import Service.Service_TheBan;
import Service.Service_ThongKe;
import Service.Service_Voucher;
import java.util.List;

/**
 *
 * @author Dell
 */
public class View_BanHang extends javax.swing.JInternalFrame {

    private DefaultTableModel mol = new DefaultTableModel();
    private Reporitories_BanHang rp = new Reporitories_BanHang();
    private Repositories_QuanLySanPham rpsp = new Repositories_QuanLySanPham();
    private Repositories_Voucher rpvc = new Repositories_Voucher();
    private Repositories_TheBan rptb = new Repositories_TheBan();

    private int HoaDonDuocChon = -1;
    private int i = -1;
    Service_BanHang svbh = new Service_BanHang();
    Service_LichSuDon svls = new Service_LichSuDon();
    Service_Login svlg = new Service_Login();
    Service_QuanLyNguyenLieu svnl = new Service_QuanLyNguyenLieu();
    Service_QuanLySanPham svsp = new Service_QuanLySanPham();
    Service_Start svst = new Service_Start();
    Service_TheBan svtb = new Service_TheBan();
    Service_ThongKe svtk = new Service_ThongKe();
    Service_Voucher svvc = new Service_Voucher();

    /**
     * Creates new form View_BanHang
     */
    public View_BanHang(Model_User user) {
        initComponents();
        this.loadData(rp.loadHoaDon());
        this.LoadSp(rpsp.getListSp());
        cbo_Voucher.removeAllItems();
        //cbo_TenBan.removeAllItems();
        //this.loadCboTheBan(rptb.getTheBan());
        this.loadCboVoucher(rpvc.getVoucher());
        System.out.println("ID là    " + user.getIDNV());
        Label_IDNV.setText(String.valueOf(user.getIDNV()));
        Label_TenNV.setText(user.getTenNV());
        this.loadDanhSachBan(rptb.getTheBan());
        cbo_FindTrangThai.removeAllItems();
        cbo_FindTrangThai.addItem("Ngưng bán");
        cbo_FindTrangThai.addItem("Đang bán");
        this.loadCboFind(rp.getDanhMuc());
        loadCategoryThuongHieu();
//        this.loadDanhSachSanPham(rpsp.getListSp());
    }

    public void loadData(ArrayList<Model_HoaDon> m) {
        mol = (DefaultTableModel) tbl_HoaDon.getModel();
        mol.setRowCount(0);
        for (Model_HoaDon x : m) {
            mol.addRow(x.toDataRowHoaDon());
        }

    }

    private void loadCategoryThuongHieu() {
        List<Model_DanhMuc> listDM = rp.getDanhMuc();
        DefaultComboBoxModel model = (DefaultComboBoxModel) Cbo_TenDoUong.getModel();
        if (!listDM.isEmpty()) {
            for (Model_DanhMuc dm : listDM) {
                model.addElement(dm.getTenDm());
            }
        }

    }

    public void loadCboFind(ArrayList<Model_DanhMuc> list) {
        DefaultComboBoxModel cbm = (DefaultComboBoxModel) Cbo_TenDoUong.getModel();
        for (Model_DanhMuc danhMuc : list) {
            cbm.addElement(danhMuc);
        }
    }

    public void LoadSp(ArrayList<Model_SanPham> list) {
        mol = (DefaultTableModel) tbl_SanPham.getModel();
        mol.setRowCount(0);
        for (Model_SanPham x : list) {
            mol.addRow(x.toDataRowBH());
        }
    }

    public void loadCboVoucher(ArrayList<Model_Voucher> list) {
        DefaultComboBoxModel cbm = (DefaultComboBoxModel) cbo_Voucher.getModel();
        for (Model_Voucher vc : list) {
            cbm.addElement(vc);
        }
    }
//    public void loadCboTheBan(ArrayList<Model_TheBan> listB) {
//        DefaultComboBoxModel cbm = (DefaultComboBoxModel) cbo_TenBan.getModel();
//        for (Model_TheBan vc : listB) {
//            cbm.addElement(vc);
//        }
//    }

    public void loadHDCT(ArrayList<Model_HoaDonChiTiet> list) {
        mol = (DefaultTableModel) tbl_HoaDonChiTiet.getModel();
        mol.setRowCount(0);
        for (Model_HoaDonChiTiet x : list) {
            mol.addRow(x.toDataHDCT());
        }
    }

    public void LoadListSp(ArrayList<Model_SanPham> list) {
        mol = (DefaultTableModel) tbl_SanPham.getModel();
        mol.setRowCount(0);
        for (Model_SanPham x : list) {
            mol.addRow(x.toDataRow());
        }
    }

    public List<Model_SanPham> loadTableSpCt() {
        DefaultTableModel model = (DefaultTableModel) tbl_SanPham.getModel();

        model.setRowCount(0);

        List<Model_SanPham> list = new ArrayList<>();

        if (txt_SearchTen.getText().trim().isEmpty()) {
            list = rp.getListSp();
        } else {
            String tenSearch = txt_SearchTen.getText();
            list = rp.TimKiemCbo(tenSearch);
        }
        for (Model_SanPham sp : list) {
            model.addRow(new Object[]{
                sp.getMaSP(),
                sp.getTenSP(),
                sp.getTenDanhMuc(),
                sp.getGiaSP(),
                sp.getTonKho(),
                sp.getTrangThai() == 0 ? "Dang Ban" : "Ngung Ban",});

        }
        return list;
    }

    public void loadDanhSachBan(ArrayList<Model_TheBan> listB) {
        Panel_DanhSachBan.removeAll();
        Panel_DanhSachBan.setLayout(new GridLayout(0, 4, 10, 10)); // 4 cột, khoảng cách 10px
        for (Model_TheBan ban : listB) {
            JButton btnBan = new JButton(ban.getTenBan() + " (" + ban.isTrangThai() + ")");
            btnBan.setPreferredSize(new Dimension(100, 100));
            btnBan.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Xử lý sự kiện khi nhấn vào bàn
                    System.out.println("Bạn đã chọn: " + ban.getTenBan());
                    // Ở đây bạn có thể thêm logic để hiển thị thông tin hóa đơn của bàn này
                    ClickBan(ban);
                }
            });

            // Thêm JButton vào Panel_DanhSachBan
            Panel_DanhSachBan.add(btnBan);
        }

        // Cập nhật giao diện
        Panel_DanhSachBan.revalidate();
        Panel_DanhSachBan.repaint();
    }

    private void LoadLaiPanel() {
        ArrayList<Model_TheBan> listB = rptb.getTheBan();// Load lại danh sách bàn từ cơ sở dữ liệu
        loadDanhSachBan(listB); // Cập nhật giao diện với danh sách bàn mới
    }

//public void loadDanhSachSanPham(ArrayList<Model_SanPham> listSP) {
//    Panel_SanPham.removeAll();
//    Panel_SanPham.setLayout(new GridLayout(0, 4, 10, 10)); // 4 cột, khoảng cách 10px
//    
//    for (Model_SanPham sp : listSP) {
//        JPanel panelSP = new JPanel();
//        panelSP.setLayout(new BorderLayout());
//        panelSP.setPreferredSize(new Dimension(200, 200)); // Kích thước tùy chỉnh cho mỗi sản phẩm
//        
//        // Thêm viền cho panel sản phẩm
//        Border border = new LineBorder(Color.BLACK, 2); // Viền đen, dày 2px
//        panelSP.setBorder(border);
//
//        // Tạo hình ảnh cho sản phẩm
//        JLabel lblImage = new JLabel(new ImageIcon(sp.getHinhAnh())); // Bạn cần thay đổi sp.getImagePath() thành đường dẫn hình ảnh thực tế
//        lblImage.setPreferredSize(new Dimension(150, 150));
//        panelSP.add(lblImage, BorderLayout.CENTER);
//
//        // Tạo tên và giá sản phẩm
//        JLabel lblName = new JLabel(sp.getTenSP(), SwingConstants.CENTER);
//        JLabel lblPrice = new JLabel(String.format("%.2f VND", sp.getGiaSP()), SwingConstants.CENTER);
//        
//        panelSP.add(lblName, BorderLayout.NORTH);
//        panelSP.add(lblPrice, BorderLayout.SOUTH);
//        
//        // Thêm ActionListener cho JPanel nếu cần (tùy chọn)
//        panelSP.addMouseListener(new MouseAdapter() {
//            @Override
//            public void mouseClicked(MouseEvent e) {
//                // Xử lý sự kiện khi nhấn vào panel sản phẩm
//                System.out.println("Bạn đã chọn sản phẩm: " + sp.getTenSP());
//                // Ở đây bạn có thể thêm logic để xử lý khi nhấn vào sản phẩm
//                //ClickSanPham(sp);
//            }
//        });
//        
//        // Thêm JPanel sản phẩm vào Panel_SanPham
//        Panel_SanPham.add(panelSP);
//    }
//
//    // Cập nhật giao diện
//    Panel_SanPham.revalidate();
//    Panel_SanPham.repaint();
//}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txt_tenKh = new javax.swing.JTextField();
        txt_SDT = new javax.swing.JTextField();
        Label_TongTienHang = new javax.swing.JLabel();
        Label_MaHD = new javax.swing.JLabel();
        Lable_MaNV = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_HoaDonChiTiet = new javax.swing.JTable();
        btn_ThanhToan = new javax.swing.JButton();
        cbo_Voucher = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Label_IDHD = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Label_TongCong = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Label_TienGiamVoucher = new javax.swing.JLabel();
        Label_TenBan = new javax.swing.JLabel();
        btn_TaoHoaDon = new javax.swing.JButton();
        Label_IDNV = new javax.swing.JLabel();
        btn_LamMoiHoaDon = new javax.swing.JButton();
        Label_TenNV = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_HoaDon = new javax.swing.JTable();
        Panel_DanhSachBan = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        Label_ConTrong = new javax.swing.JLabel();
        Label_DangSuDung = new javax.swing.JLabel();
        Label_TatCaBan = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_SanPham = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        txt_SearchTen = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        btn_Search = new javax.swing.JButton();
        Cbo_TenDoUong = new javax.swing.JComboBox<>();
        cbo_FindTrangThai = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        setPreferredSize(new java.awt.Dimension(1200, 700));

        jPanel1.setPreferredSize(new java.awt.Dimension(1200, 670));

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setText("Thành tiền");

        jLabel8.setText("SDT:");

        jLabel10.setText("Khách hàng:");

        Label_TongTienHang.setText("$$");

        Label_MaHD.setText("MaHD");

        Lable_MaNV.setText("MaNV");

        tbl_HoaDonChiTiet.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Sản phẩm", "Số lượng", "Đơn giá", "Mô tả"
            }
        ));
        tbl_HoaDonChiTiet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_HoaDonChiTietMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_HoaDonChiTiet);

        btn_ThanhToan.setText("Thanh toán");
        btn_ThanhToan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ThanhToanActionPerformed(evt);
            }
        });

        cbo_Voucher.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbo_Voucher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_VoucherActionPerformed(evt);
            }
        });

        jLabel11.setText("Số bàn:");

        jLabel2.setText("Voucher");

        Label_IDHD.setText("IDHD");

        jLabel6.setText("ID:");

        jLabel4.setText("Tổng tiền");

        Label_TongCong.setText("$$");

        jLabel7.setText("Voucher");

        Label_TienGiamVoucher.setText("$$");

        Label_TenBan.setText("Bàn X");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Lable_MaNV)
                                    .addComponent(Label_MaHD))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(2, 2, 2)
                        .addComponent(Label_IDHD)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel5)
                    .addComponent(jLabel8)
                    .addComponent(jLabel4)
                    .addComponent(jLabel7)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Label_TenBan, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(3, 3, 3)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbo_Voucher, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Label_TienGiamVoucher, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Label_TongTienHang, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_tenKh, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Label_TongCong, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_ThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_IDHD)
                    .addComponent(jLabel6))
                .addGap(4, 4, 4)
                .addComponent(Label_MaHD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Lable_MaNV)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cbo_Voucher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(Label_TenBan, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txt_tenKh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txt_SDT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Label_TongTienHang, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Label_TienGiamVoucher, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(9, 9, 9)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Label_TongCong, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                .addComponent(btn_ThanhToan, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        btn_TaoHoaDon.setText("Tạo hóa đơn");
        btn_TaoHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TaoHoaDonActionPerformed(evt);
            }
        });

        Label_IDNV.setText("ID");

        btn_LamMoiHoaDon.setText("Làm mới ");
        btn_LamMoiHoaDon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_LamMoiHoaDonActionPerformed(evt);
            }
        });

        Label_TenNV.setText("TênNV");

        tbl_HoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "IDHD", "Ngày tạo", "Người tạo", "Tổng tiền hàng", "Tổng cộng", "Bàn", "Trạng thái"
            }
        ));
        tbl_HoaDon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_HoaDonMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_HoaDon);

        Panel_DanhSachBan.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        javax.swing.GroupLayout Panel_DanhSachBanLayout = new javax.swing.GroupLayout(Panel_DanhSachBan);
        Panel_DanhSachBan.setLayout(Panel_DanhSachBanLayout);
        Panel_DanhSachBanLayout.setHorizontalGroup(
            Panel_DanhSachBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        Panel_DanhSachBanLayout.setVerticalGroup(
            Panel_DanhSachBanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 308, Short.MAX_VALUE)
        );

        Label_ConTrong.setText("Còn trống");
        Label_ConTrong.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Label_ConTrong.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Label_ConTrongMouseClicked(evt);
            }
        });

        Label_DangSuDung.setText("Đang sử dụng");
        Label_DangSuDung.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Label_DangSuDung.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Label_DangSuDungMouseClicked(evt);
            }
        });

        Label_TatCaBan.setText("Tất cả");
        Label_TatCaBan.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Label_TatCaBan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Label_TatCaBanMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(Label_TatCaBan, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Label_ConTrong, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Label_DangSuDung, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(123, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Label_ConTrong, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(Label_DangSuDung, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                    .addComponent(Label_TatCaBan, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 646, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addComponent(Panel_DanhSachBan, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Panel_DanhSachBan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Phòng Bàn", jPanel3);

        tbl_SanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã SP", "Tên sản phẩm", "Danh mục", "Giá sản phẩm"
            }
        ));
        tbl_SanPham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_SanPhamMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_SanPham);

        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setText("Tên sản phẩm");

        btn_Search.setText("Tìm kiếm");
        btn_Search.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_SearchMouseClicked(evt);
            }
        });
        btn_Search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_SearchActionPerformed(evt);
            }
        });

        Cbo_TenDoUong.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All" }));
        Cbo_TenDoUong.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                Cbo_TenDoUongItemStateChanged(evt);
            }
        });
        Cbo_TenDoUong.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Cbo_TenDoUongMouseClicked(evt);
            }
        });

        cbo_FindTrangThai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbo_FindTrangThai.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbo_FindTrangThaiItemStateChanged(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setText("Trạng thái");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setText("Danh mục");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_SearchTen, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btn_Search)
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbo_FindTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 107, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Cbo_TenDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(0, 7, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_Search, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbo_FindTrangThai, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Cbo_TenDoUong, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txt_SearchTen, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 657, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Thực Đơn", jPanel4);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 675, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btn_LamMoiHoaDon)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_TaoHoaDon)
                        .addGap(98, 98, 98)
                        .addComponent(Label_IDNV)
                        .addGap(18, 18, 18)
                        .addComponent(Label_TenNV, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_LamMoiHoaDon)
                            .addComponent(btn_TaoHoaDon)
                            .addComponent(Label_IDNV)
                            .addComponent(Label_TenNV))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 642, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tbl_SanPhamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_SanPhamMouseClicked
        // TODO add your handling code here:

        int i = tbl_SanPham.getSelectedRow();
        int soLuong = 0;
        Model_SanPham sp = rpsp.getListSp().get(i);
        String input = JOptionPane.showInputDialog(null, "Nhập số lượng sản phẩm:", "Nhập số lượng", JOptionPane.PLAIN_MESSAGE);
        int IDHD = Integer.parseInt(Label_IDHD.getText());
        if (input == null) {
            JOptionPane.showMessageDialog(null, "Thao tác đã bị hủy", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            soLuong = Integer.parseInt(input);
            if (soLuong <= 0) {
                JOptionPane.showMessageDialog(null, "Số lượng phải lớn hơn 0", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Vui lòng nhập số lượng hợp lệ", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String MoTa = JOptionPane.showInputDialog(null, "Nhập mô tả sản phẩm (chú thích):", "Nhập mô tả", JOptionPane.PLAIN_MESSAGE);

        if (MoTa == null) {
            JOptionPane.showMessageDialog(null, "Thao tác đã bị hủy", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            rp.ThemSanPhamVaoHoaDon(IDHD, sp.getIDSP(), soLuong, MoTa);
            rp.UpdateNguyenLieu(sp.getIDSP(), soLuong);
            this.loadHDCT(rp.getHoaDonChiTiet(IDHD));// load lại bảng hóa đơn chi tiết
            this.loadData(rp.loadHoaDon()); // load lại bảng hóa đơn
            int idhd = Integer.parseInt(Label_IDHD.getText());
            this.ShowHoaDonBan(rp.getHoaDonShow(idhd));
//            if (HoaDonDuocChon != -1) {
//                ShowHoaDon(HoaDonDuocChon); // Gọi hàm ShowHoaDon với chỉ số hóa đơn hiện tại
//            }
            JOptionPane.showMessageDialog(null, "Thêm sản phẩm vào hóa đơn thành công", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Có lỗi xảy ra khi thêm sản phẩm vào hóa đơn", "Lỗi", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

    }//GEN-LAST:event_tbl_SanPhamMouseClicked

    private void cbo_VoucherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_VoucherActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbo_VoucherActionPerformed

    private void btn_LamMoiHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_LamMoiHoaDonActionPerformed
        // TODO add your handling code here:
        int choice = JOptionPane.showConfirmDialog(null, "Xác nhận làm mới hóa đơn", "Làm mới hóa đơn", JOptionPane.OK_CANCEL_OPTION);

        if (choice == JOptionPane.OK_OPTION) {
            txt_SDT.setText(null);
            txt_tenKh.setText(null);
            Label_TongTienHang.setText(null);
            Label_MaHD.setText(null);
            Lable_MaNV.setText(null);

        } else {
            // Người dùng chọn Cancel hoặc đóng cửa sổ dialog
            System.out.println("Đã chọn Cancel hoặc đóng cửa sổ dialog.");
        }
    }//GEN-LAST:event_btn_LamMoiHoaDonActionPerformed

    private void btn_TaoHoaDonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_TaoHoaDonActionPerformed
        // TODO add your handling code here:
        if (rp.ModuleTaoHoaDon(getForm()) != 0) {
            JOptionPane.showMessageDialog(this, "Thêm thành công");
            this.loadData(rp.loadHoaDon());
        } else {
            JOptionPane.showMessageDialog(this, "Thêm thất bại");
        }
    }//GEN-LAST:event_btn_TaoHoaDonActionPerformed

    private void btn_ThanhToanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ThanhToanActionPerformed
        // TODO add your handling code here:
        int idhd = Integer.parseInt(Label_IDHD.getText());

        System.out.println("IDHD_ThanhToan la: " + idhd);
        Model_HoaDon hd = rp.getVoucherAndKhachHang(idhd);
        System.out.println("ThanhToan IDVC:" + hd.getIDvoucher());
        System.out.println("ThanhToan IDKH:" + hd.getIDKH());
        double tongTienTT = Double.parseDouble(Label_TongCong.getText());
        if (rp.ThanhToanHoaDon(idhd, tongTienTT) != 0) {
            if (hd.getIDvoucher() != 0) {
                rp.TruVoucher(hd.getIDvoucher());
            }
            rp.UpdateKhachHang(txt_tenKh.getText(), txt_SDT.getText(), hd.getIDKH());
            JOptionPane.showMessageDialog(this, "Thanh toán hóa đơn thành công");
            this.loadData(rp.loadHoaDon());
            this.rptb.DongBan(Label_TenBan.getText());// truyenvaoIDBAN
            DefaultTableModel model = (DefaultTableModel) tbl_HoaDonChiTiet.getModel();
            model.setRowCount(0);
            LoadLaiPanel();
            txt_SDT.setText(null);
            txt_tenKh.setText(null);
            Label_TongTienHang.setText(null);
            Label_MaHD.setText(null);
            Lable_MaNV.setText(null);
        }
    }//GEN-LAST:event_btn_ThanhToanActionPerformed

    private void tbl_HoaDonChiTietMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_HoaDonChiTietMouseClicked
        // TODO add your handling code here:
        i = tbl_HoaDonChiTiet.getSelectedRow();
        Model_HoaDon hd = rp.loadHoaDon().get(HoaDonDuocChon);
        Model_HoaDonChiTiet ct = rp.getHoaDonChiTiet(hd.getIDHD()).get(i);
        System.out.println("TenSanPham" + ct.getTenSP());
        int confirm = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn xóa sản phẩm " + ct.getTenSP() + " không?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (rp.XoaSanPhamChiTiet(hd.getIDHD(), ct.getIDSP()) != 0) {
                JOptionPane.showMessageDialog(this, "Xóa sản phẩm thành công.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                this.loadData(rp.loadHoaDon());
                this.loadHDCT(rp.getHoaDonChiTiet(hd.getIDHD()));
                this.ShowHoaDon(HoaDonDuocChon);
            } else {
                JOptionPane.showMessageDialog(this, "Xóa thất bại");
            }
        }
    }//GEN-LAST:event_tbl_HoaDonChiTietMouseClicked

    private void tbl_HoaDonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_HoaDonMouseClicked
        // TODO add your handling code here:
        HoaDonDuocChon = tbl_HoaDon.getSelectedRow();
        if (HoaDonDuocChon < 0) {
            JOptionPane.showMessageDialog(null, "Không có hóa đơn nào được chọn", "Cảnh báo", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Model_HoaDon hd = rp.loadHoaDon().get(HoaDonDuocChon);
        Label_IDHD.setText(String.valueOf(hd.getIDHD()));
        this.loadHDCT(rp.getHoaDonChiTiet(hd.getIDHD()));
        ShowHoaDon(HoaDonDuocChon);
    }//GEN-LAST:event_tbl_HoaDonMouseClicked

    private void Label_TatCaBanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Label_TatCaBanMouseClicked
        // TODO add your handling code here:
        ArrayList<Model_TheBan> listB = rptb.getTheBan();// Load lại danh sách bàn từ cơ sở dữ liệu
        loadDanhSachBan(listB);
    }//GEN-LAST:event_Label_TatCaBanMouseClicked

    private void Label_ConTrongMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Label_ConTrongMouseClicked
        // TODO add your handling code here:
        ArrayList<Model_TheBan> listB = rptb.getTheBanTrong();// Load lại danh sách bàn từ cơ sở dữ liệu
        loadDanhSachBan(listB);
    }//GEN-LAST:event_Label_ConTrongMouseClicked

    private void Label_DangSuDungMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Label_DangSuDungMouseClicked
        // TODO add your handling code here:
        ArrayList<Model_TheBan> listB = rptb.getTheBanDangSuDung();// Load lại danh sách bàn từ cơ sở dữ liệu
        loadDanhSachBan(listB);
    }//GEN-LAST:event_Label_DangSuDungMouseClicked

    private void btn_SearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_SearchMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_SearchMouseClicked

    private void btn_SearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_SearchActionPerformed
        try {
            ArrayList<Model_SanPham> listM = new ArrayList<>();
            int trangThai = cbo_FindTrangThai.getSelectedIndex();
            String ten = txt_SearchTen.getText().trim();

            for (Model_SanPham sp : rp.getListSp()) {
                boolean matchTen = ten.isEmpty() || sp.getTenSP().equalsIgnoreCase(ten);
                boolean matchTrangThai = (trangThai == 0 && sp.getTrangThai() == 0) || (trangThai == 1 && sp.getTrangThai() == 1);

                if (matchTen && matchTrangThai) {
                    listM.add(sp);
                }
            }

            mol.setRowCount(0);
            for (Model_SanPham spm : listM) {
                Object[] row = {
                    spm.getMaSP(), spm.getTenSP(), spm.getTenDanhMuc(), spm.getGiaSP(), spm.getTonKho(), spm.getTrangThai() == 0 ? "ngưng bán" : "đang bán"
                };
                mol.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btn_SearchActionPerformed

    private void Cbo_TenDoUongItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_Cbo_TenDoUongItemStateChanged
        // TODO add your handling code here:
        String Tendouong = Cbo_TenDoUong.getSelectedItem().toString();
        if (Tendouong.equals("All")) {
            LoadListSp(rp.getListSp());
        } else {
            DefaultTableModel model = (DefaultTableModel) tbl_SanPham.getModel();
            model.setRowCount(0);
            List<Model_SanPham> listLoc = new ArrayList<>();
            for (Model_SanPham sanPham : loadTableSpCt()) {
                if (sanPham.getTenDanhMuc().equals(Tendouong)) {
                    listLoc.add(sanPham);
                }
                for (Model_SanPham x : loadTableSpCt()) {
                    mol.addRow(x.toDataRow());
                }
            }
            model.setRowCount(0);
            for (Model_SanPham sp : listLoc) {
                model.addRow(new Object[]{
                    sp.getMaSP(),
                    sp.getTenSP(),
                    sp.getTenDanhMuc(),
                    sp.getGiaSP(),
                    sp.getTonKho(),
                    sp.getTrangThai() == 0 ? "Dang Ban" : "Ngung Ban",});
            }
            if (listLoc.isEmpty()) {
                model.setRowCount(0);
            }
        }
    }//GEN-LAST:event_Cbo_TenDoUongItemStateChanged

    private void Cbo_TenDoUongMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Cbo_TenDoUongMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_Cbo_TenDoUongMouseClicked

    private void cbo_FindTrangThaiItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbo_FindTrangThaiItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_cbo_FindTrangThaiItemStateChanged

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Cbo_TenDoUong;
    private javax.swing.JLabel Label_ConTrong;
    private javax.swing.JLabel Label_DangSuDung;
    private javax.swing.JLabel Label_IDHD;
    private javax.swing.JLabel Label_IDNV;
    private javax.swing.JLabel Label_MaHD;
    private javax.swing.JLabel Label_TatCaBan;
    private javax.swing.JLabel Label_TenBan;
    private javax.swing.JLabel Label_TenNV;
    private javax.swing.JLabel Label_TienGiamVoucher;
    private javax.swing.JLabel Label_TongCong;
    private javax.swing.JLabel Label_TongTienHang;
    private javax.swing.JLabel Lable_MaNV;
    private javax.swing.JPanel Panel_DanhSachBan;
    private javax.swing.JButton btn_LamMoiHoaDon;
    private javax.swing.JButton btn_Search;
    private javax.swing.JButton btn_TaoHoaDon;
    private javax.swing.JButton btn_ThanhToan;
    private javax.swing.JComboBox<String> cbo_FindTrangThai;
    private javax.swing.JComboBox<String> cbo_Voucher;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable tbl_HoaDon;
    private javax.swing.JTable tbl_HoaDonChiTiet;
    private javax.swing.JTable tbl_SanPham;
    private javax.swing.JTextField txt_SDT;
    private javax.swing.JTextField txt_SearchTen;
    private javax.swing.JTextField txt_tenKh;
    // End of variables declaration//GEN-END:variables

    public void ShowHoaDon(int i) {
        Model_HoaDon hd = rp.loadHoaDon().get(i);
        Model_Voucher vc = (Model_Voucher) cbo_Voucher.getSelectedItem();
        Label_MaHD.setText(hd.getMa());
        Lable_MaNV.setText(hd.getMaNV());
        Label_TongTienHang.setText(tbl_HoaDon.getValueAt(i, 3).toString());
        txt_SDT.setText(hd.getSDTKH());
        txt_tenKh.setText(hd.getTenKhachHang());
        String tenVc = hd.getTenVC();
        DefaultComboBoxModel cbm = (DefaultComboBoxModel) cbo_Voucher.getModel();
        for (int j = 0; j < cbm.getSize(); j++) {
            Model_Voucher vch = (Model_Voucher) cbm.getElementAt(j);
            if (vch.getTenVC().equals(tenVc)) {
                cbo_Voucher.setSelectedIndex(j);
                break;
            }
        }
        double tongTienHang = Double.parseDouble(tbl_HoaDon.getValueAt(i, 3).toString());
        Label_TongCong.setText(tbl_HoaDon.getValueAt(i, 4).toString());
        if (vc != null) {
            Double GiamGia = (tongTienHang * (vc.getPhanTramGiamGia() / 100.0)) * -1;
            System.out.println("Tiền hàng" + tongTienHang + "Giảm giá" + GiamGia);
            Label_TienGiamVoucher.setText(String.valueOf(GiamGia));
        }

    }

    public Model_HoaDon getForm() {
        Model_Voucher vc = (Model_Voucher) cbo_Voucher.getSelectedItem();
        //Model_TheBan tb = (Model_TheBan)cbo_TenBan.getSelectedItem();       
        String sdt = txt_SDT.getText().trim();
        String tenKh = txt_tenKh.getText().trim();
        int IdNV = Integer.parseInt(Label_IDNV.getText());
        int idvc = -1;
        //String vcher = String.valueOf(vc.getIdVC());
        if (vc != null) {
            idvc = vc.getIdVC();
        }
        //Model_HoaDon hd = new Model_HoaDon(idvc, 0,tenKh, sdt, IdNV);
        Model_HoaDon hd = new Model_HoaDon(idvc, 0, tenKh, sdt, IdNV);
        return hd;
        //System.out.println("BAN DA DUOC CHON LA:"+tb.getIDBan());                    
    }

    private void ClickBan(Model_TheBan ban) {
        txt_SDT.setText(null);
        txt_tenKh.setText(null);
        Label_TongTienHang.setText(null);
        Label_MaHD.setText(null);
        Lable_MaNV.setText(null);
        if (ban.isTrangThai() == true) {
            Model_HoaDon hoaDon = rptb.getHoaDonByBan(ban.getIDBan());
            System.out.println("TheBanLa" + ban.getIDBan());
            //System.out.println("HDla"+hoaDon.getIDHD());
            if (hoaDon != null) {
                // Hiển thị hóa đơn của bàn
                ShowHoaDonBan(hoaDon);
            } else {
                JOptionPane.showMessageDialog(this, "Không tìm thấy hóa đơn cho bàn này");
            }
        } else {
            System.out.println("TheBanLa" + ban.getIDBan());
            Model_HoaDon hd = getForm();
            hd.setIDBan(ban.getIDBan());
            System.out.println("TheTruyenVao la:" + hd.getIDBan());
            if (rp.ModuleTaoHoaDon(hd) != 0) {
                JOptionPane.showMessageDialog(this, "Thêm thành công");
                this.loadData(rp.loadHoaDon());
                System.out.println("IDBan before MoBan: " + hd.getIDBan());
                int result = this.rptb.MoBan(hd.getIDBan());
                if (result != 0) {
                    System.out.println("Trạng thái bàn đã được cập nhật thành công");
                    LoadLaiPanel();
                    this.ShowHoaDonBan(rptb.getHoaDonByBan(ban.getIDBan()));
                } else {
                    System.out.println("Lỗi khi cập nhật trạng thái bàn");
                }

            } else {
                JOptionPane.showMessageDialog(this, "Thêm thất bại");
            }

        }
    }

    public void ShowHoaDonBan(Model_HoaDon hd) {
        Model_Voucher vc = (Model_Voucher) cbo_Voucher.getSelectedItem();
        Label_IDHD.setText(String.valueOf(hd.getIDHD()));
        Label_MaHD.setText(hd.getMa());
        Lable_MaNV.setText(hd.getMaNV());
        Label_TongTienHang.setText(String.valueOf(hd.getTongTienHang()));
        txt_SDT.setText(hd.getSDTKH());
        txt_tenKh.setText(hd.getTenKhachHang());
        Label_TenBan.setText(hd.getTenBan());
        System.out.println("Ban Show form là: " + hd.getIDBan());
        String tenVc = hd.getTenVC();
        DefaultComboBoxModel cbm = (DefaultComboBoxModel) cbo_Voucher.getModel();
        for (int j = 0; j < cbm.getSize(); j++) {
            Model_Voucher vch = (Model_Voucher) cbm.getElementAt(j);
            if (vch.getTenVC().equals(tenVc)) {
                cbo_Voucher.setSelectedIndex(j);
                break;
            }
        }
        double tongTienHang = hd.getTongTienHang(); //Double.parseDouble(tbl_HoaDon.getValueAt(i, 3).toString());     
        Double GiamGia = 0.0;
        if (vc != null) {
            GiamGia = (tongTienHang * (vc.getPhanTramGiamGia() / 100.0)) * -1;
            //System.out.println("Tiền hàng"+tongTienHang+"Giảm giá"+GiamGia);
            Label_TienGiamVoucher.setText(String.valueOf(GiamGia));
        }
        Label_TongCong.setText(String.valueOf(tongTienHang + GiamGia));
        this.loadHDCT(rp.getHoaDonChiTiet(hd.getIDHD()));

    }

}
