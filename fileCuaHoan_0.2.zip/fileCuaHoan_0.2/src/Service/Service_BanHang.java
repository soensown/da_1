/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entity.Model_HoaDon;
import Entity.Model_HoaDonChiTiet;
import Repository.Reporitories_BanHang;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Service_BanHang {
    Repository.Reporitories_BanHang reporitories_BanHang = new Reporitories_BanHang();
    public ArrayList<Model_HoaDon> loadHoaDon() {
        return reporitories_BanHang.loadHoaDon();
    }
    
    public int TaoHoaDonMoi(Model_HoaDon hdn){
        return reporitories_BanHang.TaoHoaDonMoi(hdn);
    }
    
    public int TimKiemKhachHang(String ten, String sdt){
        return reporitories_BanHang.TimKiemKhachHang(ten, sdt);
    }
    
    public int ThemKH(String ten, String sdt) {
        return reporitories_BanHang.ThemKH(ten, sdt);
    }
    
    public int ModuleTaoHoaDon(Model_HoaDon hd) {
        return reporitories_BanHang.ModuleTaoHoaDon(hd);
    }
    
    public ArrayList<Model_HoaDonChiTiet> getHoaDonChiTiet(int idHD){
        return reporitories_BanHang.getHoaDonChiTiet(idHD);
    }
    
    public int ThemSanPhamVaoHoaDon(int IDHD,int IDSP,int SoLuong,String MoTa){
        return reporitories_BanHang.ThemSanPhamVaoHoaDon(IDHD, IDSP, SoLuong, MoTa);
    }
    
    public int ThanhToanHoaDon(int IDHD, double TongTienCanThanhToan){
        return reporitories_BanHang.ThanhToanHoaDon(IDHD, TongTienCanThanhToan);
    }
    
    public int TruVoucher(int IDVC){
        return reporitories_BanHang.TruVoucher(IDVC);
    }
    
    public int UpdateKhachHang(String ten,String sdt, int IDKH){
        return reporitories_BanHang.UpdateKhachHang(ten, sdt, IDKH);
    }
    
    public void UpdateNguyenLieu(int IDSP, int SoLuong) {
        reporitories_BanHang.UpdateNguyenLieu(IDSP, SoLuong);
    }
}
