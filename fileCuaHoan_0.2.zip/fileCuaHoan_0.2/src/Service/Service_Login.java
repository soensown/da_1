/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entity.Model_User;
import Repository.Repostitories_Login;

/**
 *
 * @author ASUS
 */
public class Service_Login {
    Repository.Repostitories_Login repostitories_Login = new Repostitories_Login();
    
    public Model_User checkLogin(String username,String passs){
        return repostitories_Login.checkLogin(username, passs);
    }
}
