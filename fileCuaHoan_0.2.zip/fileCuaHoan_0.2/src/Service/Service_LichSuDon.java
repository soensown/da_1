/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Repository.Repositories_LichSuDonHang;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Service_LichSuDon {
    Repository.Repositories_LichSuDonHang repositories_LichSuDonHang = new Repositories_LichSuDonHang();
    
    public ArrayList<Entity.Model_HoaDon> getLisHoaDon(){
        return repositories_LichSuDonHang.getLisHoaDon();
    }
}
