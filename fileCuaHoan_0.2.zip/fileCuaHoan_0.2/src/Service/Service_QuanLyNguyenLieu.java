/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entity.Model_NguyenLieu;
import Repository.Repositories_QuanLyNguyenLieu;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Service_QuanLyNguyenLieu {
    Repository.Repositories_QuanLyNguyenLieu repositories_QuanLyNguyenLieu = new Repositories_QuanLyNguyenLieu();
    
    public ArrayList<Model_NguyenLieu> getListNL() {
        return repositories_QuanLyNguyenLieu.getListNL();
    }
    
    public int themNL(Model_NguyenLieu m) {
        return repositories_QuanLyNguyenLieu.themNL(m);
    }
    
    public int capNhatNL(Model_NguyenLieu m) {
        return repositories_QuanLyNguyenLieu.capNhatNL(m);
    }
    
//    public int capNhatSoLuongNguyenLieu(float so,String ma) {
//        return repositories_QuanLyNguyenLieu.capNhatSoLuongNguyenLieu(so, ma);
//    }
    
    
}
