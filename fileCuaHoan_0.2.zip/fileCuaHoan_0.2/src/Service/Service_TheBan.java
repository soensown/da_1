/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entity.Model_TheBan;
import Repository.Repositories_TheBan;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Service_TheBan {
    Repository.Repositories_TheBan repositories_TheBan = new Repositories_TheBan();
    
    public ArrayList<Model_TheBan> getTheBan(){
        return repositories_TheBan.getTheBan();
    }
}
