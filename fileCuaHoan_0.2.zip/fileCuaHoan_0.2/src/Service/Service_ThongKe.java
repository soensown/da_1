/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entity.Model_ThongKe;
import Repository.Reporitories_ThongKe;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Service_ThongKe {

    Repository.Reporitories_ThongKe reporitories_ThongKe = new Reporitories_ThongKe();

    public ArrayList<Model_ThongKe> getListtKH() {
        return reporitories_ThongKe.getListtKH();
    }

    public int getmonth1() {
        return reporitories_ThongKe.getmonth1();
    }

    public int getmonth2() {
        return reporitories_ThongKe.getmonth2();
    }

    public int getmonth3() {
        return reporitories_ThongKe.getmonth3();
    }

    public int getmonth4() {
        return reporitories_ThongKe.getmonth4();
    }

    public int getmonth5() {
        return reporitories_ThongKe.getmonth5();
    }

    public int getmonth6() {
        return reporitories_ThongKe.getmonth6();
    }

    public int getmonth7() {
        return reporitories_ThongKe.getmonth7();
    }

    public int getmonth8() {
        return reporitories_ThongKe.getmonth8();
    }

    public int getmonth9() {
        return reporitories_ThongKe.getmonth9();
    }

    public int getmonth10() {
        return reporitories_ThongKe.getmonth10();
    }

    public int getmonth11() {
        return reporitories_ThongKe.getmonth11();
    }

    public int getmonth12() {
        return reporitories_ThongKe.getmonth12();
    }
    
    public double sumDay() {
        return reporitories_ThongKe.sumDay();
    }
    
    public double DangPhucVu() {
        return reporitories_ThongKe.DangPhucVu();
    }
    
    public double sumMonth() {
        return reporitories_ThongKe.sumMonth();
    }
    
    public double sumYear() {
        return reporitories_ThongKe.sumYear();
    }
    
    public String demSoLuongHD(String start_date, String end_date) {
        return reporitories_ThongKe.demSoLuongHD(start_date, end_date);
    }
    
    public String soLuongCacSPDaBan(String start_date, String end_date) {
        return reporitories_ThongKe.soLuongCacSPDaBan(start_date, end_date);
    }
    
    public String tongTienDaBan(String start_date, String end_date) {
        return reporitories_ThongKe.tongTienDaBan(start_date, end_date);
    }
    
    
}
