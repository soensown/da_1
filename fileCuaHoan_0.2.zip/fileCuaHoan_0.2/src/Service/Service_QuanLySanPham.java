/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entity.Model_DanhMuc;
import Entity.Model_SanPham;
import Repository.Repositories_QuanLySanPham;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Service_QuanLySanPham {
    Repository.Repositories_QuanLySanPham repositories_QuanLySanPham = new Repositories_QuanLySanPham();
    
    public ArrayList<Model_SanPham> getListSp() {
        return repositories_QuanLySanPham.getListSp();
    }
    
    public ArrayList<Model_DanhMuc> getDanhMuc(){
        return repositories_QuanLySanPham.getDanhMuc();
    }
    
    public int themSp(Model_SanPham m){
        return repositories_QuanLySanPham.themSp(m);
    }
    
    public int capNhat(Model_SanPham m){
        return repositories_QuanLySanPham.capNhat(m);
    }
    
    
}
