/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entity.Model_Voucher;
import Repository.Repositories_Voucher;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Service_Voucher {
    Repository.Repositories_Voucher repositories_Voucher = new Repositories_Voucher();
    
    public ArrayList<Model_Voucher> getVoucher(){
        return repositories_Voucher.getVoucher();
    }
    
    
}
