///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package Service;
//
//import Entity.Model_NhanVien;
//import Repository.Repositories_NhanVien;
//import java.util.ArrayList;
//
///**
// *
// * @author ASUS
// */
//public class Service_NhanVien {
//
//    Repository.Repositories_NhanVien repositories_NhanVien = new Repositories_NhanVien();
//
//    public ArrayList<Model_NhanVien> GetListNhanViens() {
//        return repositories_NhanVien.getListNhanVien();
//    }
//
//    public Integer themNhanVien(Model_NhanVien nhanVien) {
//        return repositories_NhanVien.themNhanVien(nhanVien);
//    }
//
//    public ArrayList<Model_NhanVien> timNhanVienTheoTT(int TT) {
//        return repositories_NhanVien.timNhanVienTheoTT(TT);
//    }
////    
//
//    public int capNhatNhanVien(Model_NhanVien nhanVien) {
//        return repositories_NhanVien.capNhatNhanVien(nhanVien);
//    }
////    
//
//    public ArrayList<Model_NhanVien> timNhanVienTheoTen(String hoTen) {
//        return repositories_NhanVien.timNhanVienTheoTen(hoTen);
//    }
////    
//
//    public int xoaNhanVien(Model_NhanVien nhanVien) {
//        return repositories_NhanVien.xoaNhanVien(nhanVien);
//    }
//}
//
