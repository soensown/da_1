/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author lyla
 */
public class Model_NguyenLieu {
    private int IDNL;
    private String maNl;
    private String tenNL;
    private float soLuong;
    private String DonVi;
    private String moTa;
    private int TrangThai;

    public Model_NguyenLieu() {
    }

    public Model_NguyenLieu(int IDNL, String maNl, String tenNL, float soLuong, String DonVi, String moTa, int TrangThai) {
        this.IDNL = IDNL;
        this.maNl = maNl;
        this.tenNL = tenNL;
        this.soLuong = soLuong;
        this.DonVi = DonVi;
        this.moTa = moTa;
        this.TrangThai = TrangThai;
    }

    
    

    public String getMaNl() {
        return maNl;
    }

    public void setMaNl(String maNl) {
        this.maNl = maNl;
    }

    public String getTenNL() {
        return tenNL;
    }

    public void setTenNL(String tenNL) {
        this.tenNL = tenNL;
    }

    public float getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(float soLuong) {
        this.soLuong = soLuong;
    }

    public String getDonVi() {
        return DonVi;
    }

    public void setDonVi(String DonVi) {
        this.DonVi = DonVi;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public int getTrangThai() {
        return TrangThai;
    }

    public void setTrangThai(int TrangThai) {
        this.TrangThai = TrangThai;
    }

    

    public int getIDNL() {
        return IDNL;
    }

    public void setIDNL(int IDNL) {
        this.IDNL = IDNL;
    }

    
    public Object[] toDataRow(){
        return new Object[]{this.IDNL,this.getMaNl(),this.getTenNL(),this.getSoLuong(),this.getDonVi(),this.getMoTa(),this.getTrangThai()==0?"hết hàng":"còn hàng"};
    }
    public Object[] toDataRowBH(){
        return new Object[]{this.IDNL,this.maNl,this.tenNL,this.soLuong,this.DonVi};
    }
}
