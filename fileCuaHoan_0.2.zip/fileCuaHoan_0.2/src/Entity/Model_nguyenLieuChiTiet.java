/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author lyla
 */
public class Model_nguyenLieuChiTiet {

    private int IDSP;
    private int IDNL;
    private float SoLuongSuDung;
    private String Mota;

    public Model_nguyenLieuChiTiet() {
    }

    public Model_nguyenLieuChiTiet(int IDSP, int IDNL, float SoLuongSuDung, String Mota) {
        this.IDSP = IDSP;
        this.IDNL = IDNL;
        this.SoLuongSuDung = SoLuongSuDung;
        this.Mota = Mota;
    }

    public int getIDSP() {
        return IDSP;
    }

    public void setIDSP(int IDSP) {
        this.IDSP = IDSP;
    }

    public int getIDNL() {
        return IDNL;
    }

    public void setIDNL(int IDNL) {
        this.IDNL = IDNL;
    }

    public float getSoLuongSuDung() {
        return SoLuongSuDung;
    }

    public void setSoLuongSuDung(float SoLuongSuDung) {
        this.SoLuongSuDung = SoLuongSuDung;
    }

    public String getMota() {
        return Mota;
    }

    public void setMota(String Mota) {
        this.Mota = Mota;
    }

    public Object[] toDataRow() {
        return new Object[]{this.IDSP,this.IDNL,this.SoLuongSuDung,this.Mota};
    }

    public Object[] toDataRowBH() {
        return new Object[]{this.IDSP,this.IDNL,this.SoLuongSuDung,this.Mota};
    }
}
