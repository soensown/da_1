/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author Dell
 */
public class Model_Voucher {
    private int idVC;
    private String MaVC;
    private String TenVC;
    private int PhanTramGiamGia;
    private int SoLuong;
    private String NgayBatDau;
    private String NgayKetThuc;
    private String NgayTao;
    private String NgaySua;

    public Model_Voucher(int idVC, String MaVC, String TenVC, int PhanTramGiamGia, int SoLuong, String NgayBatDau, String NgayKetThuc) {
        this.idVC = idVC;
        this.MaVC = MaVC;
        this.TenVC = TenVC;
        this.PhanTramGiamGia = PhanTramGiamGia;
        this.SoLuong = SoLuong;
        this.NgayBatDau = NgayBatDau;
        this.NgayKetThuc = NgayKetThuc;
    }

    public Model_Voucher() {
    }

    public Model_Voucher(int idVC, String MaVC, String TenVC, int PhanTramGiamGia, int SoLuong, String NgayBatDau, String NgayKetThuc, String NgayTao, String NgaySua) {
        this.idVC = idVC;
        this.MaVC = MaVC;
        this.TenVC = TenVC;
        this.PhanTramGiamGia = PhanTramGiamGia;
        this.SoLuong = SoLuong;
        this.NgayBatDau = NgayBatDau;
        this.NgayKetThuc = NgayKetThuc;
        this.NgayTao = NgayTao;
        this.NgaySua = NgaySua;
    }
    
    
    
    
    

    public int getIdVC() {
        return idVC;
    }

    public void setIdVC(int idVC) {
        this.idVC = idVC;
    }

    public String getMaVC() {
        return MaVC;
    }

    public void setMaVC(String MaVC) {
        this.MaVC = MaVC;
    }

    public String getTenVC() {
        return TenVC;
    }

    public void setTenVC(String TenVC) {
        this.TenVC = TenVC;
    }

    public int getPhanTramGiamGia() {
        return PhanTramGiamGia;
    }

    public void setPhanTramGiamGia(int PhanTramGiamGia) {
        this.PhanTramGiamGia = PhanTramGiamGia;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int SoLuong) {
        this.SoLuong = SoLuong;
    }

    public String getNgayBatDau() {
        return NgayBatDau;
    }

    public void setNgayBatDau(String NgayBatDau) {
        this.NgayBatDau = NgayBatDau;
    }

    public String getNgayKetThuc() {
        return NgayKetThuc;
    }

    public void setNgayKetThuc(String NgayKetThuc) {
        this.NgayKetThuc = NgayKetThuc;
    }

    public String getNgayTao() {
        return NgayTao;
    }

    public void setNgayTao(String NgayTao) {
        this.NgayTao = NgayTao;
    }

    public String getNgaySua() {
        return NgaySua;
    }

    public void setNgaySua(String NgaySua) {
        this.NgaySua = NgaySua;
    }
    
    @Override
    public String toString(){
        return TenVC;
    }
    
    
    
}
