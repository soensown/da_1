/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

/**
 *
 * @author admin
 */
public class Model_ThongKe {
    private String MaKH;
    private String HoTen;
    private String Sdt;
    private Float TongTien;

    public Model_ThongKe() {
    }

    public Model_ThongKe(String MaKH, String HoTen, String Sdt, Float TongTien) {
        this.MaKH = MaKH;
        this.HoTen = HoTen;
        this.Sdt = Sdt;
        this.TongTien = TongTien;
    }

    public String getMaKH() {
        return MaKH;
    }

    public void setMaKH(String MaKH) {
        this.MaKH = MaKH;
    }

    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public String getSdt() {
        return Sdt;
    }

    public void setSdt(String Sdt) {
        this.Sdt = Sdt;
    }

    public Float getTongTien() {
        return TongTien;
    }

    public void setTongTien(Float TongTien) {
        this.TongTien = TongTien;
    }
    

   
    public Object[] todataRow(){
    return new Object[]{this.MaKH,this.HoTen,this.Sdt,this.TongTien};
    }
}
